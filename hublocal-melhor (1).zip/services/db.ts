
import { DepartmentData, DepartmentId, WeightConfig, AppConfig, WeeklySnapshot, User, AccessLog } from '../types';

const DB_NAME = 'HubLocalStrategicDB';
const DB_VERSION = 5; 
const STORE_DEPARTMENTS = 'departments';
const STORE_WEIGHTS = 'weights';
const STORE_CONFIG = 'config';
const STORE_SNAPSHOTS = 'snapshots';
const STORE_USERS = 'users';
const STORE_LOGS = 'logs';

class DatabaseService {
  private db: IDBDatabase | null = null;

  async init(): Promise<void> {
    if (this.db) return; // Avoid re-opening if already open

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = (event) => {
        console.error("Erro ao abrir banco de dados", event);
        reject("Erro ao abrir banco de dados");
      };

      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        
        // Handle generic errors
        this.db.onerror = (event) => {
          console.error("Database error: " + (event.target as any).errorCode);
        };

        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        if (!db.objectStoreNames.contains(STORE_DEPARTMENTS)) {
          db.createObjectStore(STORE_DEPARTMENTS, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORE_WEIGHTS)) {
          db.createObjectStore(STORE_WEIGHTS, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORE_CONFIG)) {
          db.createObjectStore(STORE_CONFIG, { keyPath: 'key' });
        }

        if (!db.objectStoreNames.contains(STORE_SNAPSHOTS)) {
          db.createObjectStore(STORE_SNAPSHOTS, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORE_USERS)) {
          const userStore = db.createObjectStore(STORE_USERS, { keyPath: 'email' });
          userStore.createIndex('email', 'email', { unique: true });
        }

        if (!db.objectStoreNames.contains(STORE_LOGS)) {
          const logStore = db.createObjectStore(STORE_LOGS, { keyPath: 'id' });
          logStore.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
    });
  }

  /**
   * SEEDING INTELIGENTE:
   * Verifica se o banco está vazio. Se estiver, preenche com os dados iniciais.
   * Se já tiver dados, NÃO FAZ NADA, preservando o que o usuário editou.
   */
  async seedData(
    initialData: Record<string, DepartmentData>, 
    initialWeights: Record<string, WeightConfig>,
    initialConfig: AppConfig
  ): Promise<void> {
    if (!this.db) await this.init();

    return new Promise(async (resolve, reject) => {
      try {
        const transaction = this.db!.transaction([STORE_DEPARTMENTS, STORE_WEIGHTS, STORE_CONFIG, STORE_USERS], 'readwrite');
        
        // 1. Verificar Dados de Departamento
        const deptStore = transaction.objectStore(STORE_DEPARTMENTS);
        const deptCountRequest = deptStore.count();
        
        deptCountRequest.onsuccess = () => {
          if (deptCountRequest.result === 0) {
            console.log("Banco vazio. Inserindo dados iniciais de Departamentos...");
            Object.values(initialData).forEach(dept => {
              deptStore.add(dept);
            });
          }
        };

        // 2. Verificar Pesos
        const weightStore = transaction.objectStore(STORE_WEIGHTS);
        const weightCountRequest = weightStore.count();
        
        weightCountRequest.onsuccess = () => {
          if (weightCountRequest.result === 0) {
            console.log("Banco vazio. Inserindo pesos iniciais...");
            Object.entries(initialWeights).forEach(([id, config]) => {
              weightStore.add({ id, ...config });
            });
          }
        };

        // 3. Verificar Config
        const configStore = transaction.objectStore(STORE_CONFIG);
        const configCountRequest = configStore.count();

        configCountRequest.onsuccess = () => {
          if (configCountRequest.result === 0) {
             console.log("Banco vazio. Inserindo configuração inicial...");
             // Salva a config com uma chave fixa 'main'
             configStore.add({ key: 'main', ...initialConfig });
          }
        };

        // 4. Garantir Usuário Admin (Sempre checa se existe, se não, cria)
        const userStore = transaction.objectStore(STORE_USERS);
        const adminRequest = userStore.get('nagila@hublocal.com.br');
        
        adminRequest.onsuccess = () => {
            if (!adminRequest.result) {
                console.log("Criando usuário admin padrão...");
                userStore.add({
                    id: 'master-admin',
                    name: 'Nagila Oliveira',
                    email: 'nagila@hublocal.com.br',
                    password: 'Casa@1852',
                    role: 'Administrador',
                    status: 'active',
                    avatarColor: 'blue',
                    lastActive: new Date().toISOString(),
                    assignedDepartments: ['ALL']
                });
            }
        };

        transaction.oncomplete = () => resolve();
        transaction.onerror = (e) => reject(e);

      } catch (error) {
        reject(error);
      }
    });
  }

  // --- LOGGING ---
  async logAction(user: User, action: string, details: string = '', type: AccessLog['type'] = 'info'): Promise<void> {
    if (!this.db) await this.init();
    const now = new Date();
    
    const log: AccessLog = {
      id: `log-${now.getTime()}-${Math.random().toString(36).substr(2, 9)}`,
      userId: user.id,
      userName: user.name,
      action: action,
      details: details,
      type: type,
      timestamp: now.getTime(),
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString('pt-BR')
    };

    return new Promise((resolve, reject) => {
      try {
        const transaction = this.db!.transaction([STORE_LOGS], 'readwrite');
        const store = transaction.objectStore(STORE_LOGS);
        store.add(log);
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
      } catch (e) {
        reject(e);
      }
    });
  }

  async getLogs(startDate?: Date, endDate?: Date): Promise<AccessLog[]> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_LOGS], 'readonly');
      const store = transaction.objectStore(STORE_LOGS);
      const index = store.index('timestamp');
      
      let range: IDBKeyRange | null = null;
      if (startDate && endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        range = IDBKeyRange.bound(startDate.getTime(), end.getTime());
      }

      const request = range ? index.getAll(range) : index.getAll();

      request.onsuccess = () => {
        const logs = request.result as AccessLog[];
        resolve(logs.sort((a, b) => b.timestamp - a.timestamp));
      };
      request.onerror = () => reject(request.error);
    });
  }

  // --- AUTH & USERS ---
  async login(email: string, password: string): Promise<User | null> {
    if (!this.db) await this.init();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_USERS], 'readwrite');
      const store = transaction.objectStore(STORE_USERS);
      const request = store.get(email);

      request.onsuccess = () => {
        const user = request.result as User;
        if (user && user.password === password && user.status === 'active') {
          user.lastActive = new Date().toISOString();
          store.put(user);
          resolve(user);
        } else {
          resolve(null);
        }
      };
      request.onerror = () => reject(request.error);
    });
  }

  async getAllUsers(): Promise<User[]> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_USERS], 'readonly');
      const store = transaction.objectStore(STORE_USERS);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result as User[]);
      request.onerror = () => reject(request.error);
    });
  }

  async saveUser(user: User): Promise<void> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_USERS], 'readwrite');
      const store = transaction.objectStore(STORE_USERS);
      store.put(user);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  async deleteUser(email: string): Promise<void> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_USERS], 'readwrite');
      const store = transaction.objectStore(STORE_USERS);
      store.delete(email);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  // --- DATA GETTERS ---
  async getAllData(): Promise<Record<DepartmentId, DepartmentData>> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_DEPARTMENTS], 'readonly');
      const store = transaction.objectStore(STORE_DEPARTMENTS);
      const request = store.getAll();

      request.onsuccess = () => {
        const result = request.result as DepartmentData[];
        const dataMap: Record<DepartmentId, DepartmentData> = {};
        result.forEach(item => {
          dataMap[item.id] = item;
        });
        resolve(dataMap);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async getAllWeights(): Promise<Record<DepartmentId, WeightConfig>> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction([STORE_WEIGHTS], 'readonly');
        const store = transaction.objectStore(STORE_WEIGHTS);
        const request = store.getAll();

        request.onsuccess = () => {
            const result = request.result as (WeightConfig & { id: string })[];
            const map: Record<string, WeightConfig> = {};
            result.forEach(item => {
                const { id, ...rest } = item;
                map[id] = rest;
            });
            resolve(map);
        };
        request.onerror = () => reject(request.error);
    });
  }

  async getAppConfig(): Promise<AppConfig | null> {
      if (!this.db) await this.init();
      return new Promise((resolve, reject) => {
          const transaction = this.db!.transaction([STORE_CONFIG], 'readonly');
          const store = transaction.objectStore(STORE_CONFIG);
          const request = store.get('main');

          request.onsuccess = () => {
              const res = request.result;
              if (res) {
                  const { key, ...config } = res;
                  resolve(config as AppConfig);
              } else {
                  resolve(null);
              }
          };
          request.onerror = () => reject(request.error);
      });
  }

  async getSnapshots(): Promise<WeeklySnapshot[]> {
      if (!this.db) await this.init();
      return new Promise((resolve, reject) => {
          const transaction = this.db!.transaction([STORE_SNAPSHOTS], 'readonly');
          const store = transaction.objectStore(STORE_SNAPSHOTS);
          const request = store.getAll();
          request.onsuccess = () => resolve(request.result as WeeklySnapshot[]);
          request.onerror = () => reject(request.error);
      });
  }

  // --- DATA SAVERS ---
  async saveData(data: Record<DepartmentId, DepartmentData>): Promise<void> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_DEPARTMENTS], 'readwrite');
      const store = transaction.objectStore(STORE_DEPARTMENTS);
      
      Object.values(data).forEach(dept => {
          store.put(dept);
      });

      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  async saveWeights(weights: Record<DepartmentId, WeightConfig>): Promise<void> {
      if (!this.db) await this.init();
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction([STORE_WEIGHTS], 'readwrite');
        const store = transaction.objectStore(STORE_WEIGHTS);
        
        Object.entries(weights).forEach(([id, config]) => {
            store.put({ id, ...config });
        });
  
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
      });
  }

  async saveAppConfig(config: AppConfig): Promise<void> {
      if (!this.db) await this.init();
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction([STORE_CONFIG], 'readwrite');
        const store = transaction.objectStore(STORE_CONFIG);
        store.put({ key: 'main', ...config });
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
      });
  }

  async saveSnapshot(snapshot: WeeklySnapshot): Promise<void> {
      if (!this.db) await this.init();
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction([STORE_SNAPSHOTS], 'readwrite');
        const store = transaction.objectStore(STORE_SNAPSHOTS);
        store.put(snapshot);
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
      });
  }
}

export const dbService = new DatabaseService();
