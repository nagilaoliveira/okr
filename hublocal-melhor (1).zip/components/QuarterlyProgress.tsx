
import React from 'react';
import { DepartmentData, WeightConfig } from '../types';
import { Timer, TrendingUp, Target, Calendar, SlidersHorizontal } from 'lucide-react';

interface QuarterlyProgressProps {
  data: DepartmentData;
  weights: WeightConfig;
  canManageWeights: boolean;
  onOpenWeights: () => void;
}

const QuarterlyProgress: React.FC<QuarterlyProgressProps> = ({ data, weights, canManageWeights, onOpenWeights }) => {
  const startDate = new Date('2026-01-20').getTime();
  const endDate = new Date('2026-04-20').getTime();
  const today = new Date().getTime();
  
  const totalDays = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
  const daysElapsed = Math.max(0, Math.ceil((today - startDate) / (1000 * 60 * 60 * 24)));
  const daysRemaining = Math.max(0, totalDays - daysElapsed);
  const timeProgress = Math.min(100, Math.max(0, (daysElapsed / totalDays) * 100));

  let totalKpiScore = 0;
  let totalKpiWeightDivisor = 0;

  data.kpis.forEach(kpi => {
    const weight = weights.kpis[kpi.id] || (100 / data.kpis.length);
    totalKpiWeightDivisor += weight;
    let score = 0;
    if (kpi.trend === 'up') {
      score = Math.min(100, (kpi.value / kpi.target) * 100);
    } else {
      if (kpi.value <= kpi.target) {
        score = 100;
      } else {
        score = Math.max(0, (kpi.target / kpi.value) * 100);
      }
    }
    totalKpiScore += score * weight;
  });

  const normalizedKpiScore = totalKpiWeightDivisor > 0 ? totalKpiScore / totalKpiWeightDivisor : 0;
  const weightedKpiContribution = (normalizedKpiScore * weights.kpiWeight) / 100;

  let totalGoalScore = 0;
  let totalGoalWeightDivisor = 0;

  data.goals.forEach(goal => {
    const weight = weights.goals[goal.id] || (100 / data.goals.length);
    totalGoalWeightDivisor += weight;
    totalGoalScore += goal.progress * weight;
  });

  const normalizedGoalScore = totalGoalWeightDivisor > 0 ? totalGoalScore / totalGoalWeightDivisor : 0;
  const weightedGoalContribution = (normalizedGoalScore * weights.goalWeight) / 100;

  const overallProgress = weightedKpiContribution + weightedGoalContribution;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
      {/* Time Card - Green Theme */}
      <div className="bg-white rounded-3xl p-6 shadow-[0_10px_40px_-10px_rgba(0,150,85,0.15)] border border-emerald-100 relative overflow-hidden flex flex-col justify-between group hover:border-[#009655]/30 transition-all duration-300">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-bl-full -mr-10 -mt-10 transition-transform group-hover:scale-110"></div>
        
        <div className="relative z-10">
           <div className="flex items-center gap-2 mb-4">
             <div className="p-2.5 bg-[#009655] rounded-xl text-white shadow-lg shadow-[#009655]/20">
               <Calendar className="w-5 h-5" />
             </div>
             <span className="text-xs font-black uppercase tracking-widest text-[#009655]">Cronograma Q1</span>
           </div>
           
           <div className="flex items-baseline gap-2">
             <span className="text-6xl font-black text-[#000C33] tracking-tighter">{daysRemaining}</span>
             <span className="text-sm font-bold text-[#009655] bg-emerald-50 px-2 py-1 rounded-md border border-emerald-100">dias restantes</span>
           </div>
        </div>

        <div className="mt-8 relative z-10">
          <div className="flex justify-between text-[11px] font-black uppercase tracking-wider mb-2">
            <span className="text-[#000C33]/40">Decorridos: {daysElapsed} dias</span>
            <span className="text-[#009655]">{timeProgress.toFixed(0)}%</span>
          </div>
          <div className="h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-100">
            <div 
              className="h-full bg-gradient-to-r from-[#009655] to-[#4ade80] rounded-full shadow-[0_0_15px_rgba(0,150,85,0.4)]" 
              style={{ width: `${timeProgress}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Main Progress Card - Dark Futuristic */}
      <div className="lg:col-span-2 bg-[#000C33] rounded-3xl p-8 relative overflow-hidden shadow-2xl shadow-[#000C33]/30 flex flex-col justify-center">
        {/* Background Gradients */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#002FC9] opacity-20 blur-[80px] rounded-full translate-x-1/3 -translate-y-1/3"></div>
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-[#009655] opacity-10 blur-[60px] rounded-full -translate-x-1/3 translate-y-1/3"></div>

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-end gap-8">
          <div className="flex-1">
             <div className="flex items-center gap-2 mb-3">
              <span className="px-3 py-1 rounded-full bg-white/10 border border-white/10 text-white text-[10px] font-bold uppercase tracking-widest backdrop-blur-sm">
                Atingimento Geral
              </span>
            </div>
            
            <div className="flex items-center gap-6 mb-2">
              <span className="text-7xl lg:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-100 to-[#4d8aff] tracking-tighter drop-shadow-xl">
                {overallProgress.toFixed(1)}%
              </span>
              <div className="flex flex-col gap-1">
                 <span className="text-sm font-bold text-[#009655] bg-[#009655]/20 px-3 py-1.5 rounded-lg border border-[#009655]/30 inline-flex items-center">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Em dia
                </span>
                <span className="text-xs text-blue-200/60 font-medium">Meta Trimestral</span>
              </div>
            </div>
            
            <p className="text-white/60 text-sm max-w-md leading-relaxed">
              O cálculo de atingimento pondera {weights.kpiWeight}% para KPIs e {weights.goalWeight}% para Metas Operacionais.
            </p>
          </div>

          <div className="flex flex-col gap-6 w-full md:w-auto min-w-[200px]">
            {/* KPI Stat */}
            <div>
              <div className="flex justify-between items-end mb-1">
                <div className="text-[10px] uppercase font-bold text-blue-300 tracking-wider">KPIs ({weights.kpiWeight}%)</div>
                <div className="text-xl font-bold text-white">{normalizedKpiScore.toFixed(0)}%</div>
              </div>
              <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-[#002FC9] rounded-full shadow-[0_0_10px_#002FC9]" style={{ width: `${normalizedKpiScore}%` }}></div>
              </div>
            </div>

            {/* Goals Stat */}
            <div>
              <div className="flex justify-between items-end mb-1">
                <div className="text-[10px] uppercase font-bold text-blue-300 tracking-wider">Metas ({weights.goalWeight}%)</div>
                <div className="text-xl font-bold text-white">{normalizedGoalScore.toFixed(0)}%</div>
              </div>
               <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                 <div className="h-full bg-[#009655] rounded-full shadow-[0_0_10px_#009655]" style={{ width: `${normalizedGoalScore}%` }}></div>
              </div>
            </div>

            {/* Button Enhanced Visibility */}
            {canManageWeights && (
              <button 
                onClick={onOpenWeights}
                className="mt-2 w-full flex items-center justify-center gap-2 bg-white text-[#000C33] hover:bg-blue-50 font-bold py-3 px-4 rounded-xl shadow-lg shadow-black/20 transition-all transform hover:-translate-y-0.5 active:scale-95 text-xs uppercase tracking-wide"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Configurar Pesos
              </button>
            )}
          </div>
        </div>

        <div className="mt-8 relative h-4 bg-white/5 rounded-full overflow-hidden backdrop-blur-sm border border-white/10">
          <div 
            className="h-full bg-gradient-to-r from-[#002FC9] via-[#2E5CFF] to-[#009655] rounded-full shadow-[0_0_20px_rgba(0,47,201,0.5)] relative"
            style={{ width: `${overallProgress}%` }}
          >
            <div className="absolute inset-0 bg-gradient-to-b from-white/30 to-transparent"></div>
            <div className="absolute right-0 top-0 bottom-0 w-1 bg-white/50 animate-pulse box-shadow-[0_0_10px_white]"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuarterlyProgress;
