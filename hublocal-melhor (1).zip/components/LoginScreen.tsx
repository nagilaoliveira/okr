
import React, { useState } from 'react';
import { dbService } from '../services/db';
import { User } from '../types';
import { Lock, Mail, ArrowRight, AlertCircle, ShieldCheck } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const user = await dbService.login(email, password);
      if (user) {
        // Registrar Log de Login
        await dbService.logAction(user, 'Login realizado', 'Acesso ao sistema via senha', 'success');
        onLogin(user);
      } else {
        setError('Credenciais inválidas ou usuário bloqueado.');
      }
    } catch (err) {
      console.error(err);
      setError('Erro ao tentar conectar. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#000C33] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#002FC9] opacity-20 blur-[120px] rounded-full translate-x-1/3 -translate-y-1/3"></div>
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#009655] opacity-10 blur-[100px] rounded-full -translate-x-1/3 translate-y-1/3"></div>

      <div className="w-full max-w-md bg-white/10 backdrop-blur-xl border border-white/20 rounded-[32px] shadow-2xl overflow-hidden relative z-10 animate-in fade-in zoom-in-95 duration-500">
        <div className="p-8 md:p-12">
          
          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-white rounded-2xl mx-auto flex items-center justify-center shadow-lg mb-6">
               <ShieldCheck className="w-8 h-8 text-[#002FC9]" />
            </div>
            <h1 className="text-3xl font-black text-white tracking-tight">HubLocal</h1>
            <p className="text-blue-200 text-sm font-medium mt-2">Dashboard Estratégico & OKRs</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-blue-200 uppercase tracking-widest ml-1">
                Email Corporativo <span className="text-red-400">*</span>
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-blue-300 group-focus-within:text-white transition-colors" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="block w-full pl-11 pr-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-blue-300/30 focus:outline-none focus:ring-2 focus:ring-[#002FC9] focus:bg-white/10 transition-all font-medium"
                  placeholder="nome@hublocal.com.br"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-blue-200 uppercase tracking-widest ml-1">
                Senha de Acesso <span className="text-red-400">*</span>
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-blue-300 group-focus-within:text-white transition-colors" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-11 pr-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-blue-300/30 focus:outline-none focus:ring-2 focus:ring-[#002FC9] focus:bg-white/10 transition-all font-medium"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-500/20 border border-red-500/50 rounded-xl text-red-200 text-xs font-bold animate-in slide-in-from-top-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 py-4 bg-[#002FC9] hover:bg-[#0025a0] text-white rounded-xl font-bold shadow-lg shadow-blue-600/30 transition-all transform active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed mt-4"
            >
              {isLoading ? 'Autenticando...' : 'Acessar Sistema'}
              {!isLoading && <ArrowRight className="w-5 h-5" />}
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-xs text-blue-200/40">
              © 2026 HubLocal. Acesso restrito e monitorado.
            </p>
          </div>
        </div>
        
        {/* Decorative Bottom Bar */}
        <div className="h-2 w-full bg-gradient-to-r from-[#002FC9] via-blue-400 to-[#009655]"></div>
      </div>
    </div>
  );
};

export default LoginScreen;
