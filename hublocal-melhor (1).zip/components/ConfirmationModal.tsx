
import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';

interface ConfirmationModalProps {
  isOpen: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  isDangerous?: boolean;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ 
  isOpen, 
  title, 
  description, 
  confirmLabel = "Confirmar", 
  cancelLabel = "Cancelar",
  onConfirm, 
  onCancel,
  isDangerous = true
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-[#000C33]/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-[24px] w-full max-w-md shadow-2xl border border-white/20 overflow-hidden animate-in zoom-in-95 duration-200">
        
        <div className="p-6 flex flex-col items-center text-center">
          <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-lg ${isDangerous ? 'bg-red-50 text-red-500' : 'bg-blue-50 text-blue-500'}`}>
            <AlertTriangle className="w-8 h-8" strokeWidth={2} />
          </div>
          
          <h3 className="text-xl font-black text-[#000C33] mb-2">
            {title}
          </h3>
          
          <p className="text-slate-500 text-sm leading-relaxed mb-6">
            {description}
          </p>

          <div className="flex gap-3 w-full">
            <button 
              onClick={onCancel}
              className="flex-1 py-3 px-4 bg-slate-50 text-slate-600 font-bold rounded-xl hover:bg-slate-100 transition-colors text-sm"
            >
              {cancelLabel}
            </button>
            <button 
              onClick={onConfirm}
              className={`flex-1 py-3 px-4 text-white font-bold rounded-xl shadow-lg transition-all transform active:scale-95 text-sm flex items-center justify-center gap-2 ${isDangerous ? 'bg-red-500 hover:bg-red-600 shadow-red-500/30' : 'bg-[#002FC9] hover:bg-blue-700 shadow-blue-500/30'}`}
            >
              <Trash2 className="w-4 h-4" />
              {confirmLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;
