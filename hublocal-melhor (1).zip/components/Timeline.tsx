import React, { useState } from 'react';
import { Checkpoint } from '../types';
import { Check, Calendar } from 'lucide-react';

interface TimelineProps {
  checkpoints: Checkpoint[];
  onUpdate: (cp: Checkpoint) => void;
}

const Timeline: React.FC<TimelineProps> = ({ checkpoints, onUpdate }) => {
  const [editingCP, setEditingCP] = useState<Checkpoint | null>(null);

  // Sort by date
  const sorted = [...checkpoints].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  // Calculate total progress based on current date
  const startDate = new Date('2026-01-20').getTime();
  const endDate = new Date('2026-04-20').getTime();
  const now = new Date().getTime();
  const totalDuration = endDate - startDate;
  const elapsed = Math.max(0, now - startDate);
  const percentElapsed = Math.min((elapsed / totalDuration) * 100, 100);

  const handleSave = () => {
    if (editingCP) {
      onUpdate(editingCP);
      setEditingCP(null);
    }
  };

  return (
    <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-primary-dark flex items-center gap-2">
          <Calendar className="w-5 h-5 text-success" />
          Timeline Q1
        </h2>
        <div className="text-sm font-semibold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
          {Math.floor(elapsed / (1000 * 60 * 60 * 24))} dias decorridos
        </div>
      </div>

      <div className="relative pt-6 pb-2">
        {/* Progress Bar Background */}
        <div className="h-3 bg-slate-100 rounded-full w-full absolute top-1/2 -translate-y-1/2"></div>
        
        {/* Progress Bar Fill (Time elapsed) */}
        <div 
          className="h-3 bg-primary/20 rounded-full absolute top-1/2 -translate-y-1/2 transition-all duration-1000"
          style={{ width: `${percentElapsed}%` }}
        ></div>

        <div className="relative flex justify-between w-full">
          {sorted.map((cp, index) => {
             // Simple positioning based on index for demo, but ideally based on date diff
             const isPast = new Date(cp.date).getTime() < now;
             
             return (
               <div 
                 key={cp.id} 
                 onClick={() => setEditingCP(cp)}
                 className="flex flex-col items-center cursor-pointer group"
                 style={{ width: '100px' }} // fixed width for alignment
               >
                 <div 
                   className={`w-8 h-8 rounded-full border-4 flex items-center justify-center transition-all shadow-sm z-10
                   ${cp.completed 
                      ? 'bg-success border-white text-white' 
                      : isPast 
                        ? 'bg-white border-warning text-warning' 
                        : 'bg-white border-slate-300 text-slate-300'
                   } group-hover:scale-110`}
                 >
                   {cp.completed && <Check className="w-4 h-4" />}
                 </div>
                 <div className="mt-3 text-center">
                   <span className="block text-xs font-bold text-slate-700">{new Date(cp.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}</span>
                   <span className="block text-[10px] text-slate-500 leading-tight max-w-[80px] mt-1 line-clamp-2">{cp.notes}</span>
                 </div>
               </div>
             );
          })}
        </div>
      </div>

      {editingCP && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
           <div className="bg-white rounded-lg p-6 max-w-sm w-full animate-in zoom-in duration-200">
             <h3 className="font-bold text-lg mb-4">Editar Checkpoint</h3>
             
             <div className="mb-4">
               <label className="block text-sm font-medium mb-1">Data</label>
               <input 
                 type="date" 
                 value={editingCP.date}
                 onChange={e => setEditingCP({...editingCP, date: e.target.value})}
                 className="w-full border rounded p-2"
               />
             </div>
             
             <div className="mb-4">
               <label className="block text-sm font-medium mb-1">Descrição</label>
               <input 
                 type="text" 
                 value={editingCP.notes}
                 onChange={e => setEditingCP({...editingCP, notes: e.target.value})}
                 className="w-full border rounded p-2"
               />
             </div>

             <div className="mb-6 flex items-center gap-2 cursor-pointer" onClick={() => setEditingCP({...editingCP, completed: !editingCP.completed})}>
               <div className={`w-5 h-5 border rounded flex items-center justify-center ${editingCP.completed ? 'bg-success border-success' : 'border-slate-300'}`}>
                 {editingCP.completed && <Check className="w-3 h-3 text-white" />}
               </div>
               <span className="text-sm text-slate-700">Concluído</span>
             </div>

             <div className="flex justify-end gap-2">
               <button onClick={() => setEditingCP(null)} className="px-3 py-1.5 text-slate-600 font-medium hover:bg-slate-100 rounded">Cancelar</button>
               <button onClick={handleSave} className="px-3 py-1.5 bg-primary text-white font-medium rounded hover:bg-blue-700">Salvar</button>
             </div>
           </div>
        </div>
      )}
    </section>
  );
};

export default Timeline;