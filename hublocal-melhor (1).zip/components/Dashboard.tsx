
import React, { useState } from 'react';
import { DepartmentData, KPI, Goal, Checkpoint, WeightConfig, CategoryConfig, StatusConfig } from '../types';
import KPICard from './KPICard';
import GoalSection from './GoalSection';
import ChartsSection from './ChartsSection';
import QuarterlyProgress from './QuarterlyProgress';
import WeightConfigModal from './WeightConfigModal';
import KPIFormModal from './KPIFormModal';
import ConfirmationModal from './ConfirmationModal';
import { Plus } from 'lucide-react';

interface DashboardProps {
  data: DepartmentData;
  weights: WeightConfig;
  categories: Record<string, CategoryConfig>;
  statuses?: Record<string, StatusConfig>;
  permissions: {
    canCreateKPI: boolean;
    canEditKPI: boolean;
    canDeleteKPI: boolean;
    canCreateGoal: boolean;
    canEditGoal: boolean;
    canDeleteGoal: boolean;
    canEditCheckpoint: boolean;
    canManageWeights: boolean;
  };
  onUpdateKPI: (kpi: KPI) => void;
  onAddKPI: (kpi: KPI) => void;
  onDeleteKPI: (kpiId: string) => void;
  onUpdateGoal: (goal: Goal) => void;
  onDeleteGoal: (goalId: string) => void;
  onUpdateCheckpoint: (cp: Checkpoint) => void;
  onAddGoal: (goal: Goal) => void;
  onUpdateWeights: (weights: WeightConfig) => void;
}

interface DeleteState {
  isOpen: boolean;
  type: 'kpi' | 'goal';
  id: string;
  name: string;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  data, 
  weights,
  categories,
  statuses,
  permissions,
  onUpdateKPI, 
  onAddKPI,
  onDeleteKPI,
  onUpdateGoal, 
  onDeleteGoal,
  onAddGoal,
  onUpdateWeights
}) => {
  const [showWeightModal, setShowWeightModal] = useState(false);
  const [kpiModalOpen, setKpiModalOpen] = useState(false);
  const [editingKPI, setEditingKPI] = useState<KPI | null>(null);
  
  // State for Delete Confirmation
  const [deleteConfirmation, setDeleteConfirmation] = useState<DeleteState | null>(null);

  const handleOpenCreateKPI = () => {
    setEditingKPI(null);
    setKpiModalOpen(true);
  };

  const handleOpenEditKPI = (kpi: KPI) => {
    setEditingKPI(kpi);
    setKpiModalOpen(true);
  };

  const handleSaveKPI = (kpi: KPI) => {
    if (editingKPI) {
      onUpdateKPI(kpi);
    } else {
      onAddKPI({ ...kpi, id: `kpi-${Date.now()}` });
    }
    setKpiModalOpen(false);
  };

  // Intercept Delete Requests
  const requestDeleteKPI = (id: string, name: string) => {
    setDeleteConfirmation({
      isOpen: true,
      type: 'kpi',
      id,
      name
    });
  };

  const requestDeleteGoal = (id: string, title: string) => {
    setDeleteConfirmation({
      isOpen: true,
      type: 'goal',
      id,
      name: title
    });
  };

  // Execute Deletion
  const confirmDelete = () => {
    if (!deleteConfirmation) return;

    if (deleteConfirmation.type === 'kpi') {
      onDeleteKPI(deleteConfirmation.id);
      // If deleting from the modal (editing mode)
      if (editingKPI && editingKPI.id === deleteConfirmation.id) {
        setKpiModalOpen(false);
      }
    } else if (deleteConfirmation.type === 'goal') {
      onDeleteGoal(deleteConfirmation.id);
    }

    setDeleteConfirmation(null);
  };

  return (
    <div className="space-y-12 animate-fade-in pb-10">
      
      {/* Quarterly Progress Section */}
      <QuarterlyProgress 
        data={data} 
        weights={weights} 
        canManageWeights={permissions.canManageWeights}
        onOpenWeights={() => setShowWeightModal(true)} 
      />

      {/* KPI Section */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-black text-[#000C33] flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-[#009655]"></span>
              Indicadores Chave (KPIs)
            </h2>
            <p className="text-[#000C33]/40 text-sm font-bold ml-6 mt-1 uppercase tracking-widest">Performance & Métricas</p>
          </div>
          
          {permissions.canCreateKPI && (
            <button 
              onClick={handleOpenCreateKPI}
              className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 text-white text-xs font-bold uppercase tracking-wider rounded-xl hover:bg-[#002FC9] transition-all transform hover:-translate-y-1 shadow-lg shadow-slate-900/10"
            >
              <Plus className="w-4 h-4" />
              Novo KPI
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {data.kpis.map((kpi) => (
            <KPICard 
              key={kpi.id} 
              kpi={kpi} 
              canEdit={permissions.canEditKPI}
              canDelete={permissions.canDeleteKPI}
              onEdit={() => handleOpenEditKPI(kpi)}
              onDelete={() => requestDeleteKPI(kpi.id, kpi.name)}
            />
          ))}
          
          {data.kpis.length === 0 && (
             <div className="col-span-full py-12 flex flex-col items-center justify-center text-slate-400 bg-slate-50/50 rounded-[24px] border-2 border-dashed border-slate-200">
                <p className="font-bold text-sm">Nenhum KPI cadastrado.</p>
                {permissions.canCreateKPI && <button onClick={handleOpenCreateKPI} className="text-[#002FC9] font-bold text-xs mt-2 hover:underline uppercase tracking-wide">Criar o primeiro</button>}
             </div>
          )}
        </div>
      </section>

      {/* Charts Section - Hidden for VI (Vendas Indiretas) */}
      {data.id !== 'VI' && (
        <ChartsSection data={data} onUpdateKPI={onUpdateKPI} canEdit={permissions.canEditKPI} />
      )}

      {/* Goals Section */}
      <GoalSection 
        goals={data.goals} 
        categories={categories}
        statuses={statuses}
        canCreate={permissions.canCreateGoal}
        canEdit={permissions.canEditGoal}
        canDelete={permissions.canDeleteGoal}
        onUpdate={onUpdateGoal} 
        onDelete={(id) => {
           const goal = data.goals.find(g => g.id === id);
           requestDeleteGoal(id, goal?.title || 'Meta');
        }}
        onAdd={onAddGoal} 
      />

      {/* Weight Modal */}
      {showWeightModal && permissions.canManageWeights && (
        <WeightConfigModal 
          data={data}
          weights={weights}
          onSave={(w) => {
            onUpdateWeights(w);
            setShowWeightModal(false);
          }}
          onClose={() => setShowWeightModal(false)}
        />
      )}
      
      {/* KPI Form Modal (Create/Edit) */}
      {kpiModalOpen && (
        <KPIFormModal 
          initialData={editingKPI}
          onSave={handleSaveKPI}
          onDelete={(editingKPI && permissions.canDeleteKPI) ? () => requestDeleteKPI(editingKPI.id, editingKPI.name) : undefined}
          onClose={() => setKpiModalOpen(false)}
        />
      )}

      {/* Confirmation Modal */}
      <ConfirmationModal 
        isOpen={!!deleteConfirmation}
        title={`Excluir ${deleteConfirmation?.type === 'kpi' ? 'KPI' : 'Meta'}?`}
        description={`Você está prestes a excluir "${deleteConfirmation?.name}". Esta ação não pode ser desfeita e afetará o cálculo de progresso geral.`}
        confirmLabel="Sim, excluir"
        cancelLabel="Cancelar"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteConfirmation(null)}
      />
      
    </div>
  );
};

export default Dashboard;
