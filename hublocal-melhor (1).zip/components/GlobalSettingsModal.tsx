
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { AppConfig, CategoryConfig, DepartmentConfig, StatusConfig, User, DepartmentData, WeightConfig, WeeklySnapshot } from '../types';
import { dbService } from '../services/db';
import { IconResolver, ALL_ICONS, ICON_CATEGORIES } from '../utils/iconMap';
import { 
  Save, 
  Plus, 
  Trash2, 
  Layout, 
  Tags, 
  ListTodo, 
  Users, 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  UserPlus, 
  Pencil, 
  ArrowLeft, 
  Check, 
  X, 
  Search, 
  History, 
  Info, 
  BadgeCheck, 
  Ban, 
  ChevronRight, 
  Palette, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  Briefcase, 
  AlertTriangle, 
  Mail, 
  User as UserIcon, 
  Filter, 
  Download, 
  Upload, 
  Database 
} from 'lucide-react';

interface GlobalSettingsModalProps {
  config: AppConfig;
  data: Record<string, DepartmentData>;
  weights: Record<string, WeightConfig>;
  snapshots: WeeklySnapshot[];
  currentUser: User;
  onSave: (config: AppConfig) => void;
  onClose: () => void;
  onRestore?: (data: any) => void;
}

// ... imports e interfaces permanecem iguais ...
// (Mantendo constantes e interfaces para brevidade, focando nas mudanças lógicas)

// Paleta de Cores Expandida e Organizada para facilitar escolha
const COLORS = [
  // Neutros
  { name: 'slate', hex: '#64748b', label: 'Ardósia' },
  { name: 'gray', hex: '#6b7280', label: 'Cinza' },
  { name: 'zinc', hex: '#71717a', label: 'Zinco' },
  { name: 'neutral', hex: '#737373', label: 'Neutro' },
  { name: 'stone', hex: '#78716c', label: 'Pedra' },
  // Vermelhos e Rosas
  { name: 'red', hex: '#ef4444', label: 'Vermelho' },
  { name: 'rose', hex: '#f43f5e', label: 'Rosado' },
  { name: 'pink', hex: '#ec4899', label: 'Rosa' },
  // Laranjas e Amarelos
  { name: 'orange', hex: '#f97316', label: 'Laranja' },
  { name: 'amber', hex: '#f59e0b', label: 'Âmbar' },
  { name: 'yellow', hex: '#eab308', label: 'Amarelo' },
  // Verdes
  { name: 'lime', hex: '#84cc16', label: 'Lima' },
  { name: 'green', hex: '#22c55e', label: 'Verde' },
  { name: 'emerald', hex: '#10b981', label: 'Esmeralda' },
  { name: 'teal', hex: '#14b8a6', label: 'Verde-azulado' },
  // Azuis e Cianos
  { name: 'cyan', hex: '#06b6d4', label: 'Ciano' },
  { name: 'sky', hex: '#0ea5e9', label: 'Céu' },
  { name: 'blue', hex: '#3b82f6', label: 'Azul' },
  { name: 'indigo', hex: '#6366f1', label: 'Índigo' },
  // Roxos e Violetas
  { name: 'violet', hex: '#8b5cf6', label: 'Violeta' },
  { name: 'purple', hex: '#a855f7', label: 'Roxo' },
  { name: 'fuchsia', hex: '#d946ef', label: 'Fúcsia' },
];

const CAPABILITIES = [
  { id: 'view_global_dashboard', label: 'Visualizar Dashboard', category: 'Visibilidade', description: 'Acesso apenas leitura aos indicadores e metas.' },
  { id: 'view_all_departments', label: 'Navegar por Áreas', category: 'Visibilidade', description: 'Permite transitar entre departamentos sem editar dados.' },
  { id: 'goal_create', label: 'Definição de Metas', category: 'Planejamento', description: 'Permite criar novas metas estratégicas no sistema.' },
  { id: 'weights_manage', label: 'Configuração de Pesos', category: 'Planejamento', description: 'Permite atribuir relevância (pesos) entre execução, teste e reunião.' },
  { id: 'kpi_create', label: 'Criar KPIs', category: 'Resultados', description: 'Permite adicionar novos indicadores chave de performance.' },
  { id: 'kpi_edit', label: 'Editar "Realizado"', category: 'Resultados', description: 'Permite atualizar números reais. Requer integridade dos dados (evidências).' },
  { id: 'goal_edit', label: 'Atualizar Progresso Meta', category: 'Resultados', description: 'Permite alterar status e percentual de conclusão de metas operacionais.' },
  { id: 'snapshot_create', label: 'Registrar Check-in', category: 'Resultados', description: 'Permite salvar o histórico semanal de evolução.' },
  { id: 'kpi_delete', label: 'Excluir KPIs', category: 'Avançado', description: 'Remover indicadores permanentemente.' },
  { id: 'goal_delete', label: 'Excluir Metas', category: 'Avançado', description: 'Remover metas permanentemente.' },
  { id: 'settings_manage', label: 'Alterar Regras Globais', category: 'Administração', description: 'Acesso total às configurações do sistema que afetam todos os usuários.' },
  { id: 'users_manage', label: 'Gerenciar Usuários', category: 'Administração', description: 'Criar, editar e bloquear acesso de usuários.' },
  { id: 'logs_view', label: 'Auditoria e Logs', category: 'Administração', description: 'Visualizar histórico de ações para segurança.' },
];

interface AccessLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  details?: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: number;
  date: string;
  time: string;
  ip?: string;
}

// ... Componentes auxiliares (IconPickerOverlay, ColorPickerGrid) mantidos iguais ...
const IconPickerOverlay = ({ 
  currentIcon, 
  onSelect, 
  onClose 
}: { 
  currentIcon: string, 
  onSelect: (icon: string) => void, 
  onClose: () => void 
}) => {
  const [search, setSearch] = useState('');
  
  const filteredIcons = useMemo(() => {
    if (!search) return Object.keys(ALL_ICONS);
    return Object.keys(ALL_ICONS).filter(k => k.toLowerCase().includes(search.toLowerCase()));
  }, [search]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#000C33]/60 backdrop-blur-sm animate-in fade-in p-4">
      <div className="bg-white rounded-[24px] w-full max-w-2xl h-[70vh] flex flex-col shadow-2xl border border-white/20 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-3 bg-white shrink-0">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Buscar ícone..." 
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[#002FC9]"
              autoFocus
            />
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 bg-[#F8FAFC]">
          <div className="grid grid-cols-6 sm:grid-cols-8 gap-3">
            {filteredIcons.map(iconName => (
              <button
                key={iconName}
                onClick={() => { onSelect(iconName); onClose(); }}
                className={`aspect-square flex items-center justify-center rounded-xl transition-all ${
                  currentIcon === iconName 
                    ? 'bg-[#002FC9] text-white shadow-lg ring-2 ring-offset-2 ring-[#002FC9]' 
                    : 'bg-white border border-slate-200 text-slate-400 hover:border-blue-300 hover:text-[#002FC9] hover:shadow-md'
                }`}
                title={iconName}
              >
                <IconResolver iconName={iconName} className="w-6 h-6" />
              </button>
            ))}
          </div>
          {filteredIcons.length === 0 && (
            <div className="text-center py-20 text-slate-400 text-sm">Nenhum ícone encontrado.</div>
          )}
        </div>
      </div>
    </div>
  );
};

const ColorPickerGrid = ({ selected, onChange }: { selected: string, onChange: (c: string) => void }) => {
  return (
    <div className="flex flex-wrap gap-1.5 mt-2 max-w-xs">
      {COLORS.map(c => (
        <button
          key={c.name}
          onClick={() => onChange(c.name)}
          className={`w-6 h-6 rounded-full transition-transform hover:scale-110 flex items-center justify-center border border-black/5 ${selected === c.name ? 'ring-2 ring-offset-1 ring-slate-400 scale-110 shadow-sm' : 'hover:opacity-80'}`}
          style={{ backgroundColor: c.hex }}
          title={c.label}
        >
          {selected === c.name && <Check className="w-3 h-3 text-white drop-shadow-sm" strokeWidth={3} />}
        </button>
      ))}
    </div>
  );
};

const GlobalSettingsModal: React.FC<GlobalSettingsModalProps> = ({ config, data, weights, snapshots, currentUser, onSave, onClose, onRestore }) => {
  const [activeTab, setActiveTab] = useState<'areas' | 'categories' | 'statuses' | 'users' | 'permissions' | 'history' | 'backup'>('areas');
  const [localConfig, setLocalConfig] = useState<AppConfig>(JSON.parse(JSON.stringify(config)));
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Controle do Picker de Ícone
  const [iconPickerState, setIconPickerState] = useState<{
    isOpen: boolean;
    targetId: string | number; // ID ou Index
    currentIcon: string;
    type: 'dept' | 'cat' | 'status';
  } | null>(null);

  // Controle de Deleção de Departamento (Usando ID para segurança)
  const [deptToDeleteId, setDeptToDeleteId] = useState<string | null>(null);
  const [deptToDeleteName, setDeptToDeleteName] = useState<string>('');

  // Estado de Usuários e Filtros
  const [users, setUsers] = useState<User[]>([]);
  const [isUserFormOpen, setIsUserFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<User> & { password?: string }>({});
  const [userFilter, setUserFilter] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Estado de Permissões
  const [selectedRole, setSelectedRole] = useState<string>('Administrador');
  const [newRoleName, setNewRoleName] = useState('');
  const [isAddingRole, setIsAddingRole] = useState(false);

  // Estado de Logs
  const [accessLogs, setAccessLogs] = useState<AccessLog[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);
  const [logFilter, setLogFilter] = useState('');

  // Initial Loaders
  useEffect(() => {
    if (activeTab === 'users') {
      dbService.getAllUsers().then(setUsers).catch(console.error);
    }
    if (activeTab === 'history') {
      setIsLoadingLogs(true);
      dbService.getLogs().then(setAccessLogs).catch(console.error).finally(() => setIsLoadingLogs(false));
    }
  }, [activeTab]);

  // ... (Other handlers kept same: openIconPicker, handleIconSelect, Department handlers, Category handlers, Status handlers, User handlers, Permission handlers)
  
  const openIconPicker = (type: 'dept' | 'cat' | 'status', id: string | number, currentIcon: string) => {
    setIconPickerState({ isOpen: true, targetId: id, currentIcon, type });
  };

  const handleIconSelect = (icon: string) => {
    if (!iconPickerState) return;
    const { type, targetId } = iconPickerState;

    if (type === 'dept') {
      handleUpdateDept(targetId as number, 'icon', icon);
    } else if (type === 'cat') {
      handleUpdateCategory(targetId as string, 'icon', icon);
    } else if (type === 'status') {
      handleUpdateStatus(targetId as string, 'icon', icon);
    }
  };

  // --- Departments ---
  const handleAddDept = () => {
    const newId = `DEPT-${Date.now().toString().slice(-4)}`;
    setLocalConfig(prev => ({
      ...prev,
      departments: [...prev.departments, { id: newId, name: 'Nova Área', icon: 'Target' }]
    }));
  };
  const handleUpdateDept = (index: number, field: keyof DepartmentConfig, value: string) => {
    const updated = [...localConfig.departments];
    updated[index] = { ...updated[index], [field]: value };
    setLocalConfig(prev => ({ ...prev, departments: updated }));
  };
  
  const requestDeleteDept = (id: string, name: string) => {
    setDeptToDeleteId(id);
    setDeptToDeleteName(name);
  };

  const confirmDeleteDept = () => {
    if (!deptToDeleteId) return;
    // Filtra pelo ID para garantir que apagamos o certo mesmo se a ordem mudou na lista
    const updated = localConfig.departments.filter(d => d.id !== deptToDeleteId);
    setLocalConfig(prev => ({ ...prev, departments: updated }));
    setDeptToDeleteId(null);
    setDeptToDeleteName('');
  };

  // --- Categories ---
  const handleUpdateCategory = (id: string, field: keyof CategoryConfig, value: string) => {
    setLocalConfig(prev => ({ ...prev, categories: { ...prev.categories, [id]: { ...prev.categories[id], [field]: value } } }));
  };
  const handleAddCategory = () => {
      const id = `Custom-${Date.now().toString().slice(-4)}`;
      setLocalConfig(prev => ({ ...prev, categories: { ...prev.categories, [id]: { id, label: 'Nova Categoria', colorTheme: 'slate', icon: 'Box' } } }));
  };
  const handleDeleteCategory = (id: string) => {
      const updated = { ...localConfig.categories }; delete updated[id]; setLocalConfig(prev => ({ ...prev, categories: updated }));
  };

  // --- Statuses ---
  const handleUpdateStatus = (id: string, field: keyof StatusConfig, value: string) => {
      setLocalConfig(prev => ({ ...prev, statuses: { ...prev.statuses, [id]: { ...prev.statuses[id], [field]: value } } }));
  };
  const handleAddStatus = () => {
      const id = `Status-${Date.now().toString().slice(-4)}`;
      setLocalConfig(prev => ({ ...prev, statuses: { ...prev.statuses, [id]: { id, label: 'Novo Status', colorTheme: 'slate', icon: 'Circle' } } }));
  };
  const handleDeleteStatus = (id: string) => {
      const updated = { ...localConfig.statuses }; delete updated[id]; setLocalConfig(prev => ({ ...prev, statuses: updated }));
  };

  // --- Users Logic ---
  const handleOpenUserForm = (user?: User) => {
    setShowPassword(false);
    if (user) {
      setEditingUser({ ...user, password: '' }); 
    } else {
      setEditingUser({ 
        name: '', 
        email: '', 
        role: 'Visualizador', 
        status: 'active', 
        avatarColor: 'slate', 
        password: '', 
        lastActive: 'Nunca', 
        assignedDepartments: [] 
      });
    }
    setIsUserFormOpen(true);
  };

  const handleSaveUser = async () => {
    if (!editingUser.name || !editingUser.email) return;
    if (!editingUser.id && !editingUser.password) { alert("Senha é obrigatória."); return; }
    
    const userToSave: User = { 
        id: editingUser.id || `user-${Date.now()}`, 
        name: editingUser.name, 
        email: editingUser.email, 
        role: editingUser.role || 'Visualizador', 
        status: editingUser.status as any, 
        avatarColor: editingUser.avatarColor || 'blue', 
        lastActive: editingUser.lastActive || 'Nunca', 
        assignedDepartments: editingUser.assignedDepartments || [], 
        password: editingUser.password || (editingUser as any).password 
    };

    if (editingUser.id && !editingUser.password) {
        const oldUser = users.find(u => u.id === editingUser.id);
        if (oldUser) userToSave.password = oldUser.password;
    }

    await dbService.saveUser(userToSave);
    await dbService.logAction(currentUser, editingUser.id ? 'Editou Usuário' : 'Criou Usuário', `Usuário: ${userToSave.email}`, 'info');
    setUsers(await dbService.getAllUsers());
    setIsUserFormOpen(false);
  };

  const handleToggleBlockUser = async (user: User) => {
    const updatedUser = { ...user, status: user.status === 'active' ? 'blocked' : 'active' } as User;
    await dbService.saveUser(updatedUser);
    setUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));
  };

  const handleDeleteUser = async (email: string) => {
    if (confirm('Excluir usuário?')) {
        await dbService.deleteUser(email);
        setUsers(prev => prev.filter(u => u.email !== email));
    }
  };

  const handleToggleDepartment = (deptId: string) => {
    const currentDepts = editingUser.assignedDepartments || [];
    if (currentDepts.includes(deptId)) {
      setEditingUser({ ...editingUser, assignedDepartments: currentDepts.filter(id => id !== deptId) });
    } else {
      setEditingUser({ ...editingUser, assignedDepartments: [...currentDepts, deptId] });
    }
  };

  // --- Permissions Logic ---
  const availableRoles = Object.keys(localConfig.rolePermissions || { 'Administrador': [], 'Gestor': [], 'Operacional': [] });
  const handleAddRole = () => {
    if (!newRoleName.trim() || localConfig.rolePermissions?.[newRoleName]) return;
    setLocalConfig(prev => ({ ...prev, rolePermissions: { ...(prev.rolePermissions || {}), [newRoleName]: [] } }));
    setSelectedRole(newRoleName); setNewRoleName(''); setIsAddingRole(false);
  };
  const handleDeleteRole = (roleToDelete: string) => {
    if (roleToDelete === 'Administrador' || !confirm(`Excluir perfil "${roleToDelete}"?`)) return;
    const newPermissions = { ...localConfig.rolePermissions }; delete newPermissions[roleToDelete];
    setLocalConfig(prev => ({ ...prev, rolePermissions: newPermissions }));
    if (selectedRole === roleToDelete) setSelectedRole('Administrador');
  };
  const togglePermission = (role: string, capabilityId: string) => {
    setLocalConfig(prev => {
      const currentPerms = prev.rolePermissions?.[role] || [];
      const newPerms = currentPerms.includes(capabilityId) ? currentPerms.filter(id => id !== capabilityId) : [...currentPerms, capabilityId];
      if (role === 'Administrador' && !newPerms.includes('ALL')) { if (!newPerms.includes('ALL')) newPerms.push('ALL'); }
      return { ...prev, rolePermissions: { ...prev.rolePermissions, [role]: newPerms } };
    });
  };
  const hasPermission = (role: string, capabilityId: string) => {
    const perms = localConfig.rolePermissions?.[role] || [];
    if (perms.includes('ALL')) return true;
    return perms.includes(capabilityId);
  };
  const groupedCapabilities = CAPABILITIES.reduce((acc, cap) => {
    if (!acc[cap.category]) acc[cap.category] = []; acc[cap.category].push(cap); return acc;
  }, {} as Record<string, typeof CAPABILITIES>);

  // --- BACKUP LOGIC ---
  const handleExportData = () => {
    const backupData = {
      timestamp: new Date().toISOString(),
      version: '1.0',
      data: data,
      weights: weights,
      config: config,
      snapshots: snapshots
    };
    
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hublocal_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    console.log("Iniciando importação do arquivo:", file.name);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        
        console.log("Arquivo parseado com sucesso. Verificando estrutura...");

        // Relaxed validation - if it has at least 'data' or 'config', try to load
        if (parsed.data || parsed.config) {
          if (confirm('ATENÇÃO: Isso irá substituir os dados atuais pelos do backup. Deseja continuar?')) {
             if (onRestore) {
                console.log("Chamando função de restauração...");
                onRestore(parsed);
             } else {
                console.error("Função onRestore não fornecida ao modal.");
             }
          }
        } else {
          alert('Arquivo de backup inválido ou corrompido (falta data ou config).');
        }
      } catch (err) {
        console.error("Erro ao processar arquivo de backup:", err);
        alert('Erro ao ler o arquivo JSON. Verifique se o formato está correto.');
      } finally {
        // Reset input value directly via ref to allow re-selecting the same file if needed
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
      }
    };
    reader.readAsText(file);
  };

  // Render Helpers
  const SidebarItem = ({ id, label, icon: Icon }: { id: typeof activeTab, label: string, icon: any }) => (
    <button
      onClick={() => { setActiveTab(id); setIsUserFormOpen(false); }}
      className={`w-full flex items-center gap-3 px-4 py-3.5 text-sm font-bold rounded-xl transition-all duration-200 group ${
        activeTab === id ? 'bg-[#002FC9]/10 text-[#002FC9] shadow-sm' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
      }`}
    >
      <Icon className={`w-5 h-5 ${activeTab === id ? 'text-[#002FC9]' : 'text-slate-400 group-hover:text-slate-600'}`} />
      <span>{label}</span>
      {activeTab === id && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#002FC9]"></div>}
    </button>
  );

  const filteredUsers = users.filter(user => user.name.toLowerCase().includes(userFilter.toLowerCase()) || user.email.toLowerCase().includes(userFilter.toLowerCase()));

  // ... (Rest of the render method remains structurally identical, just ensuring file input uses ref) ...

  return (
    <>
      <div className="fixed inset-0 bg-[#000C33]/90 z-50 flex items-center justify-center backdrop-blur-md p-4 animate-in fade-in">
        {/* ... Modal Structure ... */}
        <div className="bg-white rounded-[32px] w-full max-w-6xl h-[85vh] flex flex-col shadow-2xl overflow-hidden border border-white/20">
          
          {/* Header */}
          <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-white shrink-0">
            <div>
              <h3 className="font-black text-2xl text-[#000C33]">Configurações Globais</h3>
              <p className="text-sm text-slate-500 font-medium">Gerencie áreas, categorias, usuários e permissões.</p>
            </div>
            <button onClick={onClose} className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-[#000C33] transition-colors font-bold text-xl">&times;</button>
          </div>

          <div className="flex flex-1 overflow-hidden">
            {/* Sidebar */}
            <div className="w-64 bg-white border-r border-slate-100 p-4 flex flex-col gap-1 overflow-y-auto shrink-0">
               {/* ... Sidebar Items ... */}
               <div className="px-4 py-2 text-[10px] font-black uppercase tracking-widest text-slate-400">Geral</div>
               <SidebarItem id="areas" label="Áreas & Depts" icon={Layout} />
               <SidebarItem id="categories" label="Categorias" icon={Tags} />
               <SidebarItem id="statuses" label="Status" icon={ListTodo} />
               <div className="px-4 py-2 mt-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Acesso & Segurança</div>
               <SidebarItem id="users" label="Usuários" icon={Users} />
               <SidebarItem id="permissions" label="Permissões" icon={Shield} />
               <SidebarItem id="backup" label="Backup & Dados" icon={Database} />
               {hasPermission(currentUser.role || 'Visualizador', 'logs_view') && (
                 <SidebarItem id="history" label="Histórico de Acesso" icon={History} />
               )}
            </div>

            {/* Content */}
            <div className="flex-1 bg-[#F8FAFC] overflow-y-auto p-8 relative min-w-0">
              
              {/* ... Areas, Categories, Statuses, Users, Permissions Tabs (Hidden for brevity, same logic) ... */}
              {activeTab === 'areas' && (
                <div className="space-y-6 max-w-4xl">
                   {/* ... Areas Content ... */}
                   <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-black text-xl text-[#000C33]">Áreas e Departamentos</h4>
                      <p className="text-sm text-slate-500 font-medium mt-1">Gerencie a estrutura organizacional da empresa.</p>
                    </div>
                    <span className="text-xs font-bold bg-blue-100 text-blue-700 px-3 py-1.5 rounded-lg border border-blue-200">{localConfig.departments.length} Áreas Ativas</span>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    {localConfig.departments.map((dept, index) => (
                      <div key={dept.id} className="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 group hover:shadow-md hover:border-blue-200 transition-all duration-300">
                        <button 
                           onClick={() => openIconPicker('dept', index, dept.icon)}
                           className="w-14 h-14 flex items-center justify-center shrink-0 bg-slate-50 rounded-xl hover:bg-blue-50 text-slate-500 hover:text-blue-600 transition-colors border border-slate-100"
                           title="Alterar Ícone"
                        >
                           <IconResolver iconName={dept.icon} className="w-7 h-7" />
                        </button>

                        <div className="flex-1 min-w-0">
                          <div className="relative group/input">
                            <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Nome do Departamento</label>
                            <input 
                              className="w-full text-base font-bold text-[#000C33] bg-transparent border-b border-transparent focus:border-[#002FC9] hover:border-slate-200 focus:outline-none py-1 transition-all placeholder:text-slate-300 focus:bg-slate-50 px-2 rounded" 
                              value={dept.name} 
                              onChange={(e) => handleUpdateDept(index, 'name', e.target.value)}
                              placeholder="Nome do Departamento" 
                            />
                          </div>
                        </div>

                        <div className="px-4 border-l border-slate-100">
                           <span className="text-[10px] font-bold text-slate-400 uppercase block">ID Interno</span>
                           <span className="font-mono text-xs font-medium text-slate-600">{dept.id}</span>
                        </div>

                        <button 
                          onClick={() => requestDeleteDept(dept.id, dept.name)} 
                          className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-colors shrink-0"
                          title="Excluir Área"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <button onClick={handleAddDept} className="w-full py-4 border-2 border-dashed border-slate-300 rounded-2xl text-slate-400 font-bold hover:border-[#002FC9] hover:text-[#002FC9] hover:bg-blue-50/50 transition-all flex items-center justify-center gap-2 group">
                    <div className="w-8 h-8 rounded-full bg-slate-100 group-hover:bg-[#002FC9] group-hover:text-white flex items-center justify-center transition-colors">
                      <Plus className="w-5 h-5" />
                    </div>
                    Adicionar Nova Área
                  </button>
                </div>
              )}

              {activeTab === 'categories' && (
                 <div className="space-y-6 max-w-5xl">
                   {/* ... Categories Content ... */}
                   <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="font-black text-xl text-[#000C33]">Categorias Estratégicas</h4>
                        <p className="text-sm text-slate-500 font-medium mt-1">Classifique as metas por pilares de negócio.</p>
                      </div>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                     {Object.values(localConfig.categories).map((cat: CategoryConfig) => (
                       <div key={cat.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col group hover:shadow-lg hover:border-blue-200 transition-all duration-300 overflow-hidden relative">
                          <div className={`h-1.5 w-full bg-${cat.colorTheme}-500`}></div>
                          <div className="p-5 flex flex-col gap-4 relative">
                             <button onClick={() => handleDeleteCategory(cat.id)} className="absolute top-3 right-3 p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"><Trash2 className="w-4 h-4" /></button>
                             <div className="flex items-start gap-4">
                                <button onClick={() => openIconPicker('cat', cat.id, cat.icon)} className={`w-12 h-12 flex items-center justify-center shrink-0 rounded-xl bg-${cat.colorTheme}-50 text-${cat.colorTheme}-600 hover:ring-2 hover:ring-${cat.colorTheme}-200 transition-all`}>
                                   <IconResolver iconName={cat.icon} className="w-6 h-6" />
                                </button>
                                <div className="flex-1"><label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Nome</label><input className="w-full font-bold text-[#000C33] text-lg bg-transparent border-b border-transparent focus:border-slate-300 focus:bg-slate-50 px-1 -ml-1 rounded focus:outline-none transition-all" value={cat.label} onChange={(e) => handleUpdateCategory(cat.id, 'label', e.target.value)} /></div>
                             </div>
                             <div><label className="text-[10px] font-bold text-slate-400 uppercase block flex items-center gap-2"><Palette className="w-3 h-3" /> Paleta de Cores</label><ColorPickerGrid selected={cat.colorTheme} onChange={(c) => handleUpdateCategory(cat.id, 'colorTheme', c)} /></div>
                          </div>
                       </div>
                     ))}
                     <button onClick={handleAddCategory} className="min-h-[250px] border-2 border-dashed border-slate-300 rounded-2xl text-slate-400 font-bold hover:border-[#002FC9] hover:text-[#002FC9] hover:bg-blue-50/50 transition-all flex flex-col items-center justify-center gap-3 group"><div className="w-12 h-12 rounded-full bg-slate-100 group-hover:bg-[#002FC9] group-hover:text-white flex items-center justify-center transition-colors shadow-sm"><Plus className="w-6 h-6" /></div><span>Nova Categoria</span></button>
                   </div>
                 </div>
              )}

              {activeTab === 'statuses' && (
                <div className="space-y-6 max-w-5xl">
                  {/* ... Statuses Content ... */}
                  <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="font-black text-xl text-[#000C33]">Status de Execução</h4>
                        <p className="text-sm text-slate-500 font-medium mt-1">Defina as etapas de progresso das iniciativas.</p>
                      </div>
                   </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {Object.values(localConfig.statuses || {}).map((status: StatusConfig) => (
                      <div key={status.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col group hover:shadow-lg hover:border-blue-200 transition-all duration-300 overflow-hidden relative">
                          <div className={`h-1.5 w-full bg-${status.colorTheme}-500`}></div>
                          <div className="p-5 flex flex-col gap-4 relative">
                             <button onClick={() => handleDeleteStatus(status.id)} className="absolute top-3 right-3 p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"><Trash2 className="w-4 h-4" /></button>
                             <div className="flex items-start gap-4">
                                <button onClick={() => openIconPicker('status', status.id, status.icon)} className={`w-12 h-12 flex items-center justify-center shrink-0 rounded-xl bg-${status.colorTheme}-50 text-${status.colorTheme}-600 hover:ring-2 hover:ring-${status.colorTheme}-200 transition-all`}>
                                   <IconResolver iconName={status.icon} className="w-6 h-6" />
                                </button>
                                <div className="flex-1"><label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Rótulo</label><input className="w-full font-bold text-[#000C33] text-lg bg-transparent border-b border-transparent focus:border-slate-300 focus:bg-slate-50 px-1 -ml-1 rounded focus:outline-none transition-all" value={status.label} onChange={(e) => handleUpdateStatus(status.id, 'label', e.target.value)} /></div>
                             </div>
                             <div><label className="text-[10px] font-bold text-slate-400 uppercase block flex items-center gap-2"><Palette className="w-3 h-3" /> Paleta de Cores</label><ColorPickerGrid selected={status.colorTheme} onChange={(c) => handleUpdateStatus(status.id, 'colorTheme', c)} /></div>
                          </div>
                      </div>
                    ))}
                    <button onClick={handleAddStatus} className="min-h-[250px] border-2 border-dashed border-slate-300 rounded-2xl text-slate-400 font-bold hover:border-[#002FC9] hover:text-[#002FC9] hover:bg-blue-50/50 transition-all flex flex-col items-center justify-center gap-3 group"><div className="w-12 h-12 rounded-full bg-slate-100 group-hover:bg-[#002FC9] group-hover:text-white flex items-center justify-center transition-colors shadow-sm"><Plus className="w-6 h-6" /></div><span>Novo Status</span></button>
                  </div>
                </div>
              )}

              {activeTab === 'users' && (
                <div className="space-y-6 max-w-5xl h-full flex flex-col">
                  {/* ... Users Content (Kept same) ... */}
                  {!isUserFormOpen ? (
                    <>
                      <div className="flex justify-between items-center flex-wrap gap-4"><h4 className="font-black text-lg text-[#000C33]">Gerenciamento de Usuários</h4><div className="flex items-center gap-3"><div className="relative"><input type="text" placeholder="Buscar usuário..." value={userFilter} onChange={(e) => setUserFilter(e.target.value)} className="pl-9 pr-4 py-2 rounded-xl bg-white border border-slate-200 text-sm focus:outline-none focus:border-[#002FC9] w-48 md:w-64 transition-all" /><Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" /></div><button onClick={() => handleOpenUserForm()} className="flex items-center gap-2 px-4 py-2 bg-[#002FC9] text-white rounded-xl text-xs font-bold hover:bg-[#0025a0] transition-colors shadow-lg shadow-blue-500/20 whitespace-nowrap"><UserPlus className="w-4 h-4" /> <span className="hidden sm:inline">Novo Usuário</span></button></div></div>
                      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex-1 flex flex-col">
                         <div className="flex-1 overflow-y-auto p-4 space-y-3">
                           {filteredUsers.map(user => {
                             const isBlocked = user.status === 'blocked';
                             return (
                               <div key={user.id} className={`flex flex-col md:flex-row items-start md:items-center justify-between p-4 rounded-xl border transition-all gap-4 ${isBlocked ? 'bg-slate-50 border-slate-200 opacity-80' : 'bg-white border-slate-100 hover:border-blue-200 hover:shadow-sm'}`}>
                                 <div className="flex items-center gap-4 min-w-0 flex-1">
                                   <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-white shadow-sm text-lg shrink-0 ${isBlocked ? 'bg-slate-400' : `bg-${user.avatarColor}-500`}`}>{user.name.substring(0, 2).toUpperCase()}</div>
                                   <div className="min-w-0"><div className="flex items-center gap-2 mb-0.5"><h5 className={`font-bold text-sm truncate ${isBlocked ? 'text-slate-500 line-through decoration-slate-300' : 'text-[#000C33]'}`}>{user.name}</h5>{isBlocked && <span className="text-[9px] text-white bg-red-500 px-1.5 rounded font-bold uppercase tracking-wide">Bloqueado</span>}</div><div className="text-xs text-slate-400 truncate">{user.email}</div><div className="flex flex-wrap gap-1.5 mt-2"><span className="px-2 py-0.5 rounded text-[10px] font-bold border bg-slate-50 border-slate-200 text-slate-600">{user.role}</span>{user.assignedDepartments?.map(deptId => (<span key={deptId} className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded border border-blue-100 text-[10px] font-bold uppercase">{deptId === 'ALL' ? 'Global' : deptId}</span>))}</div></div>
                                 </div>
                                 <div className="flex items-center gap-2"><button onClick={() => handleOpenUserForm(user)} className="p-2 text-slate-400 hover:text-[#002FC9] hover:bg-blue-50 rounded-lg transition-colors cursor-pointer" title="Editar Cadastro"><Pencil className="w-4 h-4" /></button><button onClick={() => handleToggleBlockUser(user)} className={`p-2 rounded-lg transition-colors flex items-center gap-2 cursor-pointer ${isBlocked ? 'text-emerald-500 bg-emerald-50 hover:bg-emerald-100' : 'text-slate-400 hover:text-red-500 hover:bg-red-50'}`} title={isBlocked ? 'Desbloquear Acesso' : 'Bloquear Acesso'}>{isBlocked ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}</button><button onClick={() => handleDeleteUser(user.email)} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors cursor-pointer" title="Excluir Usuário"><Trash2 className="w-4 h-4" /></button></div>
                               </div>
                             );
                           })}
                         </div>
                      </div>
                    </>
                  ) : (
                    // ... User Form ...
                    <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden animate-in fade-in slide-in-from-right-4 duration-300 h-full flex flex-col">
                      <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50"><div className="flex items-center gap-3"><button onClick={() => setIsUserFormOpen(false)} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white text-slate-400 hover:text-[#002FC9] transition-all hover:shadow-sm"><ArrowLeft className="w-4 h-4" /></button><h4 className="font-black text-lg text-[#000C33]">{editingUser.id ? 'Editar Usuário' : 'Novo Cadastro'}</h4></div><div className="flex gap-2"><button onClick={() => setIsUserFormOpen(false)} className="px-4 py-2 text-slate-500 font-bold hover:bg-slate-100 rounded-lg transition-colors text-xs">Cancelar</button><button onClick={handleSaveUser} className="px-5 py-2 bg-[#002FC9] text-white font-bold rounded-lg hover:bg-[#0025a0] shadow-sm flex items-center gap-2 text-xs"><Save className="w-3 h-3" /> Salvar</button></div></div>
                      <div className="flex-1 overflow-y-auto p-4 bg-[#F8FAFC]">
                        <div className="max-w-5xl mx-auto grid grid-cols-12 gap-4 h-full">
                          <div className="col-span-12 md:col-span-4 space-y-4">
                             <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm h-full flex flex-col items-center text-center"><div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold text-white shadow-lg mb-3 bg-${editingUser.avatarColor || 'blue'}-500`}>{editingUser.name ? editingUser.name.substring(0, 2).toUpperCase() : <UserIcon className="w-6 h-6 opacity-50" />}</div><div className="w-full space-y-2.5"><div><label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1 block text-left">Nome</label><input className="w-full text-xs font-bold text-[#000C33] bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:border-[#002FC9] outline-none transition-all" value={editingUser.name} onChange={(e) => setEditingUser({...editingUser, name: e.target.value})} placeholder="Ex: João Silva" autoFocus /></div><div><label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1 block text-left">Email</label><div className="relative"><input type="email" className="w-full text-xs font-medium text-slate-600 bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-2.5 py-1.5 focus:border-[#002FC9] outline-none transition-all" value={editingUser.email} onChange={(e) => setEditingUser({...editingUser, email: e.target.value})} placeholder="user@hublocal.com.br" disabled={!!editingUser.id} /><Mail className="absolute left-2.5 top-2 w-3 h-3 text-slate-400" /></div></div><div><label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1 block text-left">Senha</label><div className="relative"><input type={showPassword ? "text" : "password"} className="w-full text-xs font-medium text-slate-600 bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-8 py-1.5 focus:border-[#002FC9] outline-none transition-all" value={editingUser.password} onChange={(e) => setEditingUser({...editingUser, password: e.target.value})} placeholder={editingUser.id ? "••••••••" : "Senha segura"} /><Key className="absolute left-2.5 top-2 w-3 h-3 text-slate-400" /><button onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-2 text-slate-400 hover:text-slate-600 focus:outline-none" type="button">{showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}</button></div></div><div className="pt-2 mt-2 border-t border-slate-100 w-full"><div className="flex bg-slate-100 p-1 rounded-lg"><button type="button" onClick={() => setEditingUser({...editingUser, status: 'active'})} className={`flex-1 py-1 rounded-md text-[10px] font-bold transition-all flex items-center justify-center gap-1.5 ${editingUser.status === 'active' ? 'bg-white text-[#009655] shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}><Check className="w-3 h-3" /> Ativo</button><button type="button" onClick={() => setEditingUser({...editingUser, status: 'blocked'})} className={`flex-1 py-1.5 rounded-md text-[10px] font-bold transition-all flex items-center justify-center gap-1.5 ${editingUser.status === 'blocked' ? 'bg-white text-red-500 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}><Ban className="w-3 h-3" /> Block</button></div></div></div></div>
                          </div>
                          <div className="col-span-12 md:col-span-8 space-y-4">
                             <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm"><h5 className="font-bold text-xs text-[#000C33] mb-3 flex items-center gap-2 uppercase tracking-wide border-b border-slate-100 pb-2"><Shield className="w-3.5 h-3.5 text-slate-400" /> Perfil de Permissão</h5><div className="grid grid-cols-3 gap-2">{availableRoles.map(role => (<label key={role} className={`flex items-center gap-2 p-2 rounded-lg border cursor-pointer transition-all ${editingUser.role === role ? 'bg-blue-50 border-blue-200 text-blue-700 shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`}><div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${editingUser.role === role ? 'border-blue-500 bg-blue-500' : 'border-slate-300 bg-white'}`}>{editingUser.role === role && <div className="w-1.5 h-1.5 rounded-full bg-white" />}</div><input type="radio" name="role" className="hidden" value={role} checked={editingUser.role === role} onChange={() => setEditingUser({...editingUser, role: role as any})} /><span className="text-[11px] font-bold truncate">{role}</span></label>))}</div></div>
                             <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex-1"><h5 className="font-bold text-xs text-[#000C33] mb-3 flex items-center gap-2 uppercase tracking-wide border-b border-slate-100 pb-2"><Briefcase className="w-3.5 h-3.5 text-slate-400" /> Acesso a Departamentos</h5><div className="space-y-2"><label className={`flex items-center gap-3 p-2 rounded-lg border cursor-pointer transition-all ${editingUser.assignedDepartments?.includes('ALL') ? 'bg-[#000C33] border-[#000C33] text-white shadow-md' : 'bg-slate-50 border-slate-200 text-[#000C33] hover:bg-slate-100'}`}><div className={`w-4 h-4 rounded border flex items-center justify-center ${editingUser.assignedDepartments?.includes('ALL') ? 'border-white bg-white/20' : 'border-slate-400'}`}>{editingUser.assignedDepartments?.includes('ALL') && <Check className="w-3 h-3 text-white" />}</div><input type="checkbox" className="hidden" checked={editingUser.assignedDepartments?.includes('ALL')} onChange={() => handleToggleDepartment('ALL')} /><span className="text-[11px] font-bold uppercase">Acesso Global (Todas as áreas)</span></label><div className={`grid grid-cols-2 sm:grid-cols-3 gap-2 transition-opacity ${editingUser.assignedDepartments?.includes('ALL') ? 'opacity-50 pointer-events-none' : ''}`}>{localConfig.departments.map(dept => (<label key={dept.id} className={`flex items-center gap-2 p-2 rounded-lg border cursor-pointer transition-all ${editingUser.assignedDepartments?.includes(dept.id) ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}><div className={`w-3.5 h-3.5 rounded border flex items-center justify-center transition-colors shrink-0 ${editingUser.assignedDepartments?.includes(dept.id) ? 'bg-blue-500 border-blue-500' : 'border-slate-300 bg-white'}`}>{editingUser.assignedDepartments?.includes(dept.id) && <Check className="w-2.5 h-2.5 text-white" />}</div><input type="checkbox" className="hidden" checked={editingUser.assignedDepartments?.includes(dept.id) || false} onChange={() => handleToggleDepartment(dept.id)} disabled={editingUser.assignedDepartments?.includes('ALL')} /><span className="text-[10px] font-bold truncate">{dept.name}</span></label>))}</div></div></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* --- PERMISSIONS TAB --- */}
              {activeTab === 'permissions' && (
                <div className="flex h-full gap-6 overflow-hidden">
                  <div className="w-1/3 flex flex-col border-r border-slate-100 pr-6 shrink-0"><div className="flex justify-between items-center mb-6"><h4 className="font-black text-lg text-[#000C33]">Perfis de Acesso</h4></div><div className="mb-4">{isAddingRole ? (<div className="flex gap-2 animate-in fade-in slide-in-from-left-2"><input type="text" value={newRoleName} onChange={(e) => setNewRoleName(e.target.value)} placeholder="Nome..." className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-sm focus:outline-none focus:border-[#002FC9]" autoFocus /><button onClick={handleAddRole} className="p-2 bg-[#002FC9] text-white rounded-xl"><Check className="w-4 h-4" /></button><button onClick={() => setIsAddingRole(false)} className="p-2 bg-slate-100 text-slate-500 rounded-xl"><X className="w-4 h-4" /></button></div>) : <button onClick={() => setIsAddingRole(true)} className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-slate-200 rounded-xl text-slate-400 font-bold hover:border-[#002FC9] hover:text-[#002FC9] hover:bg-blue-50 transition-all text-xs uppercase tracking-wide"><Plus className="w-4 h-4" /> Novo Perfil</button>}</div><div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">{availableRoles.map(role => (<div key={role} onClick={() => setSelectedRole(role)} className={`flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all border ${selectedRole === role ? 'bg-[#002FC9] border-[#002FC9] text-white shadow-lg' : 'bg-white border-slate-100 text-slate-600 hover:bg-slate-50'}`}><div className="flex items-center gap-3">{role === 'Administrador' ? <BadgeCheck className="w-5 h-5" /> : <Users className="w-5 h-5 opacity-70" />}<span className="font-bold text-sm truncate max-w-[120px]">{role}</span></div>{role !== 'Administrador' && <button onClick={(e) => { e.stopPropagation(); handleDeleteRole(role); }} className="p-1.5 rounded-lg hover:bg-red-500 hover:text-white text-slate-300"><Trash2 className="w-4 h-4" /></button>}</div>))}</div></div><div className="flex-1 flex flex-col h-full overflow-hidden min-w-0"><div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 shrink-0"><div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-[#002FC9]"><Shield className="w-5 h-5" /></div><div><h4 className="font-black text-lg text-[#000C33]">{selectedRole}</h4><span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{hasPermission(selectedRole, 'ALL') ? 'Acesso Total' : 'Permissões Personalizadas'}</span></div></div></div><div className="flex-1 overflow-y-auto overflow-x-hidden pr-2 custom-scrollbar space-y-8">{Object.entries(groupedCapabilities).map(([category, caps]) => (<div key={category}><h5 className="font-bold text-xs text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>{category}</h5><div className="grid grid-cols-1 xl:grid-cols-2 gap-3">{caps.map(cap => { const isActive = hasPermission(selectedRole, cap.id); const isAdmin = selectedRole === 'Administrador'; return (<div key={cap.id} onClick={() => !isAdmin && togglePermission(selectedRole, cap.id)} className={`flex items-start gap-3 p-4 rounded-xl border transition-all cursor-pointer select-none group h-full ${isActive ? 'bg-blue-50/50 border-blue-200' : 'bg-white border-slate-100 hover:border-slate-300'} ${isAdmin ? 'opacity-70 cursor-not-allowed' : ''}`}><div className={`w-6 h-6 rounded-md flex items-center justify-center transition-colors shrink-0 mt-0.5 ${isActive ? 'bg-[#002FC9] text-white shadow-sm' : 'bg-slate-100 text-slate-300'}`}>{isActive && <Check className="w-3.5 h-3.5" strokeWidth={3} />}</div><div className="flex-1 min-w-0"><span className={`block font-bold text-sm leading-tight ${isActive ? 'text-[#000C33]' : 'text-slate-500'}`}>{cap.label}</span><p className={`text-[11px] leading-relaxed mt-1.5 ${isActive ? 'text-blue-700/70' : 'text-slate-400'}`}>{cap.description}</p></div></div>); })}</div></div>))}</div></div>
                </div>
              )}

              {/* --- BACKUP TAB --- */}
              {activeTab === 'backup' && (
                <div className="max-w-2xl space-y-8">
                   <div>
                      <h4 className="font-black text-xl text-[#000C33]">Backup e Restauração</h4>
                      <p className="text-sm text-slate-500 font-medium mt-1">Gerencie cópias de segurança dos dados estratégicos.</p>
                   </div>

                   <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                      <div className="flex items-center gap-4 mb-4">
                         <div className="p-3 bg-blue-50 rounded-xl text-[#002FC9]">
                            <Download className="w-6 h-6" />
                         </div>
                         <div>
                            <h5 className="font-bold text-[#000C33]">Exportar Dados</h5>
                            <p className="text-xs text-slate-500">Baixe um arquivo JSON com todas as metas, KPIs e configurações atuais.</p>
                         </div>
                      </div>
                      <button 
                        onClick={handleExportData}
                        className="w-full py-3 bg-[#002FC9] hover:bg-[#0025a0] text-white rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20"
                      >
                        Baixar Backup Agora
                      </button>
                   </div>

                   <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-1 h-full bg-amber-400"></div>
                      <div className="flex items-center gap-4 mb-4">
                         <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
                            <Upload className="w-6 h-6" />
                         </div>
                         <div>
                            <h5 className="font-bold text-[#000C33]">Restaurar Dados</h5>
                            <p className="text-xs text-slate-500">Importe um arquivo de backup para recuperar informações perdidas.</p>
                         </div>
                      </div>
                      <div className="relative">
                        <input 
                          ref={fileInputRef}
                          id="backup-input"
                          type="file" 
                          accept=".json"
                          onChange={handleImportData}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                        />
                        <button className="w-full py-3 bg-slate-50 hover:bg-slate-100 text-slate-600 border-2 border-dashed border-slate-200 hover:border-amber-300 rounded-xl font-bold transition-all flex items-center justify-center gap-2">
                           <Upload className="w-4 h-4" /> Selecionar Arquivo de Backup
                        </button>
                      </div>
                      <div className="mt-3 p-3 bg-amber-50 rounded-lg flex items-start gap-2">
                         <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                         <p className="text-[10px] text-amber-700 font-medium leading-relaxed">
                           Atenção: A restauração irá <strong>substituir</strong> todos os dados atuais (KPIs, metas, pesos) pelos dados do arquivo. Certifique-se de que este é o arquivo correto.
                         </p>
                      </div>
                   </div>
                </div>
              )}

              {/* ... History Tab Content (Kept same) ... */}
              {activeTab === 'history' && (
                  <div className="h-full flex flex-col">
                     <div className="flex flex-col gap-4 mb-6"><div className="flex justify-between items-center"><h4 className="font-black text-lg text-[#000C33]">Histórico de Acesso</h4><button onClick={() => { setIsLoadingLogs(true); dbService.getLogs().then(setAccessLogs).finally(() => setIsLoadingLogs(false)); }} className="text-xs text-[#002FC9] font-bold hover:underline flex items-center gap-1"><History className="w-3 h-3" /> Atualizar</button></div><div className="relative"><div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Filter className="w-4 h-4 text-slate-400" /></div><input type="text" placeholder="Filtrar por Nome, Data (DD/MM), Ação ou Detalhes..." value={logFilter} onChange={(e) => setLogFilter(e.target.value)} className="w-full pl-10 pr-10 py-3 bg-white border-2 border-slate-100 rounded-xl text-sm focus:outline-none focus:border-[#002FC9] focus:ring-4 focus:ring-[#002FC9]/5 transition-all text-[#000C33] font-semibold placeholder:text-slate-300" />{logFilter && (<button onClick={() => setLogFilter('')} className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 transition-colors"><X className="w-4 h-4" /></button>)}</div></div><div className="flex-1 overflow-auto bg-white rounded-2xl border border-slate-200 shadow-sm relative">{isLoadingLogs ? <div className="flex items-center justify-center h-full text-slate-400 font-bold text-sm animate-pulse">Carregando logs...</div> : ((() => { const filteredLogs = accessLogs.filter(log => { if (!logFilter) return true; const search = logFilter.toLowerCase(); const dateFormatted = new Date(log.date).toLocaleDateString(); return (log.userName.toLowerCase().includes(search) || log.action.toLowerCase().includes(search) || (log.details || '').toLowerCase().includes(search) || dateFormatted.includes(search) || log.date.includes(search)); }); if (filteredLogs.length === 0) return (<div className="flex flex-col items-center justify-center h-full text-slate-400 gap-3"><div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center"><Search className="w-8 h-8 opacity-20" /></div><span className="text-sm font-medium">Nenhum registro encontrado para "{logFilter}".</span></div>); return (<table className="w-full relative"><thead className="bg-slate-50 sticky top-0 z-10 border-b border-slate-200 shadow-sm"><tr><th className="text-left py-3 px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-32">Data/Hora</th><th className="text-left py-3 px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Usuário</th><th className="text-left py-3 px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Ação</th><th className="text-left py-3 px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Detalhes</th><th className="text-center py-3 px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-24">Tipo</th></tr></thead><tbody className="divide-y divide-slate-100">{filteredLogs.map(log => { let typeColor = 'bg-slate-100 text-slate-600'; let TypeIcon = Info; if (log.type === 'success') { typeColor = 'bg-emerald-50 text-emerald-600 border-emerald-100'; TypeIcon = Check; } else if (log.type === 'warning') { typeColor = 'bg-amber-50 text-amber-600 border-amber-100'; TypeIcon = AlertCircle; } else if (log.type === 'error') { typeColor = 'bg-rose-50 text-rose-600 border-rose-100'; TypeIcon = X; } else { typeColor = 'bg-blue-50 text-blue-600 border-blue-100'; } return (<tr key={log.id} className="hover:bg-slate-50/50 transition-colors"><td className="py-3 px-4 text-xs font-medium text-slate-500 whitespace-nowrap"><div className="flex flex-col"><span className="font-bold text-[#000C33]">{new Date(log.date).toLocaleDateString()}</span><span className="text-[10px]">{log.time}</span></div></td><td className="py-3 px-4 text-xs font-bold text-[#000C33]">{log.userName}</td><td className="py-3 px-4 text-xs font-medium text-slate-700">{log.action}</td><td className="py-3 px-4 text-xs text-slate-500 max-w-xs truncate" title={log.details}>{log.details}</td><td className="py-3 px-4 text-center"><span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md border text-[10px] font-bold uppercase tracking-wide ${typeColor}`}><TypeIcon className="w-3 h-3" />{log.type === 'info' ? 'Info' : log.type === 'success' ? 'Ok' : log.type === 'warning' ? 'Alert' : 'Erro'}</span></td></tr>); })}</tbody></table>); })())}</div>
                  </div>
              )}
            </div>
          </div>

          <div className="p-6 bg-white border-t border-slate-200 flex justify-end gap-3 shrink-0">
             <button onClick={onClose} className="px-6 py-3 text-[#000C33] font-bold hover:bg-[#EDF1FF] rounded-xl transition-colors text-sm">Cancelar</button>
             <button onClick={() => onSave(localConfig)} className="px-6 py-3 bg-[#002FC9] text-white font-bold rounded-xl hover:bg-[#0025a0] flex items-center gap-2 shadow-lg shadow-[#002FC9]/20 transform active:scale-95 transition-all text-sm"><Save className="w-4 h-4" /> Salvar Configurações</button>
          </div>
        </div>
      </div>

      {/* Render Icon Picker if Open */}
      {iconPickerState && iconPickerState.isOpen && (
        <IconPickerOverlay 
          currentIcon={iconPickerState.currentIcon}
          onSelect={handleIconSelect}
          onClose={() => setIconPickerState(null)}
        />
      )}

      {/* MODAL DE CONFIRMAÇÃO DE EXCLUSÃO DE DEPARTAMENTO */}
      {deptToDeleteId !== null && (
        <div className="fixed inset-0 bg-[#000C33]/80 z-[120] flex items-center justify-center backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl overflow-hidden p-6 text-center animate-in zoom-in-95 duration-200">
             <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4 text-red-600">
                <AlertTriangle className="w-8 h-8" />
             </div>
             <h3 className="text-xl font-bold text-[#000C33] mb-2">Excluir Departamento?</h3>
             <p className="text-sm text-slate-500 mb-6">
               Você está prestes a remover <strong>{deptToDeleteName}</strong>. 
               Isso ocultará a área do menu principal.
             </p>
             <div className="flex gap-3">
               <button 
                 onClick={() => { setDeptToDeleteId(null); setDeptToDeleteName(''); }}
                 className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors"
               >
                 Cancelar
               </button>
               <button 
                 onClick={confirmDeleteDept}
                 className="flex-1 py-2.5 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl transition-colors shadow-lg shadow-red-500/30"
               >
                 Sim, Excluir
               </button>
             </div>
          </div>
        </div>
      )}
    </>
  );
};

export default GlobalSettingsModal;
