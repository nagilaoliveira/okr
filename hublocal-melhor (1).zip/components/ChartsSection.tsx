
import React, { useState, useRef, useEffect } from 'react';
import { DepartmentData, KPI } from '../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { TrendingUp, TrendingDown, BarChart2, Target, Settings, CheckSquare, Square } from 'lucide-react';

interface ChartsSectionProps {
  data: DepartmentData;
  canEdit: boolean;
  onUpdateKPI: (kpi: KPI) => void;
}

const ChartsSection: React.FC<ChartsSectionProps> = ({ data, canEdit, onUpdateKPI }) => {
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const configRef = useRef<HTMLDivElement>(null);

  // Close config when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (configRef.current && !configRef.current.contains(event.target as Node)) {
        setIsConfigOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Filter KPIs based on chartVisible property (default to true if undefined)
  const filteredKpis = data.kpis.filter(k => k.chartVisible !== false);

  const kpiChartData = filteredKpis.map(k => ({
    name: k.name.length > 15 ? k.name.substring(0, 15) + '...' : k.name,
    fullTitle: k.name,
    Realizado: k.value,
    Meta: k.target,
    unit: k.unit,
    trend: k.trend
  }));

  const goalChartData = data.goals.map(g => ({
    name: g.title.length > 35 ? g.title.substring(0, 32) + '...' : g.title,
    fullTitle: g.title,
    progress: g.progress,
    category: g.category
  }));

  // Find max progress to adjust chart domain
  const maxProgress = Math.max(100, ...data.goals.map(g => g.progress));

  const formatValue = (value: number, unit: string) => {
    switch (unit) {
      case 'currency':
        return new Intl.NumberFormat('pt-BR', { 
          style: 'currency', 
          currency: 'BRL', 
          minimumFractionDigits: 0, 
          maximumFractionDigits: 0 
        }).format(value);
      case 'percent':
        return new Intl.NumberFormat('pt-BR', { 
          style: 'decimal', 
          minimumFractionDigits: 1, 
          maximumFractionDigits: 2 
        }).format(value) + '%';
      case 'rating':
        return value.toFixed(1);
      default:
        return new Intl.NumberFormat('pt-BR').format(value);
    }
  };

  const toggleKPIVisibility = (kpi: KPI) => {
    if (!canEdit) return;
    onUpdateKPI({
      ...kpi,
      chartVisible: kpi.chartVisible === false ? true : false
    });
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const { fullTitle, unit, trend } = data;
      
      const isUp = trend === 'up';
      const TrendIcon = isUp ? TrendingUp : TrendingDown;
      const trendColor = isUp ? 'text-[#009655]' : 'text-red-400';
      const trendBg = isUp ? 'bg-[#009655]/20' : 'bg-red-500/20';

      return (
        <div className="bg-[#000C33] p-4 border border-white/10 shadow-2xl rounded-xl text-xs text-white z-50 min-w-[220px]">
          <div className="flex justify-between items-start gap-4 mb-3 pb-3 border-b border-white/10">
            <p className="font-bold text-white text-sm leading-tight flex-1">{fullTitle}</p>
            <div className={`flex items-center gap-1 px-2 py-1 rounded-md ${trendBg} ${trendColor} shrink-0`}>
              <TrendIcon className="w-3 h-3" />
            </div>
          </div>
          
          {payload.map((entry: any, index: number) => {
            if (entry.dataKey !== 'Realizado' && entry.dataKey !== 'Meta') return null;
            const formattedValue = formatValue(entry.value, unit);

            return (
              <div key={index} className="flex items-center justify-between gap-4 mb-2 last:mb-0">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }}></span>
                  <span className="opacity-70 text-[10px] uppercase font-bold tracking-wider">{entry.name}</span> 
                </div>
                <span className="font-bold font-mono text-sm">{formattedValue}</span>
              </div>
            );
          })}
        </div>
      );
    }
    return null;
  };

  const GoalTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const entry = payload[0];
      const title = entry.payload.fullTitle || label;
      const category = entry.payload.category;
      const progress = entry.value;
      const isCompleted = progress >= 100;
      
      return (
        <div className="bg-[#000C33] p-5 border border-white/10 shadow-2xl rounded-2xl text-xs text-white z-50 min-w-[280px] backdrop-blur-md">
           <div className="flex items-center justify-between mb-3 pb-3 border-b border-white/10">
             <span className="px-2.5 py-1 rounded-md bg-white/10 border border-white/5 text-[10px] font-bold uppercase tracking-widest text-blue-200">
               {category}
             </span>
             <div className="flex items-center gap-1.5">
               <span className={`w-2 h-2 rounded-full ${isCompleted ? 'bg-[#009655] shadow-[0_0_8px_#009655]' : 'bg-[#002FC9] shadow-[0_0_8px_#002FC9]'}`}></span>
               <span className="font-black text-lg leading-none tracking-tight text-white">
                 {progress}%
               </span>
             </div>
           </div>

           <p className="font-bold text-sm text-white leading-relaxed mb-3">
             {title}
           </p>

           <div className="flex flex-col gap-1.5">
              <div className="flex justify-between text-[10px] uppercase font-bold text-white/40 tracking-wider">
                <span>Progresso</span>
                <span>{progress > 100 ? 'Superado' : isCompleted ? 'Concluído' : 'Em andamento'}</span>
              </div>
              <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${isCompleted ? 'bg-[#009655]' : 'bg-[#002FC9]'}`}
                  style={{ width: `${Math.min(progress, 100)}%` }} 
                />
              </div>
           </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
      {/* Financial/KPI Chart */}
      <div className="bg-gradient-to-br from-white to-blue-50/30 p-8 rounded-[32px] shadow-sm border border-slate-100 relative overflow-visible group hover:shadow-lg transition-all duration-300">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-indigo-600 rounded-t-[32px]"></div>
        
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 rounded-xl text-[#002FC9]">
              <BarChart2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-[#000C33]">Indicadores de Performance</h3>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                Realizado vs Meta
              </p>
            </div>
          </div>

          {/* Config Dropdown */}
          <div className="relative" ref={configRef}>
            {canEdit && (
              <button 
                onClick={() => setIsConfigOpen(!isConfigOpen)}
                className={`p-2 rounded-xl transition-all ${isConfigOpen ? 'bg-[#002FC9] text-white shadow-lg' : 'text-slate-300 hover:text-[#002FC9] hover:bg-white hover:shadow-md'}`}
                title="Configurar visualização"
              >
                <Settings className="w-5 h-5" />
              </button>
            )}

            {isConfigOpen && (
              <div className="absolute right-0 top-12 w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 z-50 p-4 animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-50">
                  <span className="text-xs font-black text-[#000C33] uppercase tracking-widest">Exibir no Gráfico</span>
                  <span className="text-[10px] text-slate-400 font-bold">{filteredKpis.length} visíveis</span>
                </div>
                <div className="space-y-1 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
                  {data.kpis.map((kpi) => {
                    const isVisible = kpi.chartVisible !== false;
                    return (
                      <button 
                        key={kpi.id}
                        onClick={() => toggleKPIVisibility(kpi)}
                        className={`w-full flex items-center gap-3 p-2 rounded-lg text-left transition-colors group ${isVisible ? 'bg-blue-50/50 hover:bg-blue-50' : 'hover:bg-slate-50'}`}
                      >
                        <div className={`${isVisible ? 'text-[#002FC9]' : 'text-slate-300 group-hover:text-slate-400'}`}>
                          {isVisible ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                        </div>
                        <span className={`text-xs font-bold truncate ${isVisible ? 'text-[#000C33]' : 'text-slate-400'}`}>
                          {kpi.name}
                        </span>
                      </button>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="h-80 w-full mt-6">
          {kpiChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={kpiChartData}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                barGap={8}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 10, fontWeight: 700}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10}} />
                <Tooltip content={<CustomTooltip />} cursor={{fill: '#F1F5F9', opacity: 0.5}} />
                <Bar dataKey="Realizado" fill="#002FC9" radius={[4, 4, 0, 0] as [number, number, number, number]} barSize={20}>
                  {kpiChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill="url(#colorRealizado)" />
                  ))}
                </Bar>
                <Bar dataKey="Meta" fill="#CBD5E1" radius={[4, 4, 0, 0] as [number, number, number, number]} barSize={20} />
                <defs>
                  <linearGradient id="colorRealizado" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#002FC9" stopOpacity={1}/>
                    <stop offset="100%" stopColor="#002FC9" stopOpacity={0.7}/>
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-slate-300 border-2 border-dashed border-slate-100 rounded-2xl bg-slate-50/50">
              <BarChart2 className="w-8 h-8 mb-2 opacity-50" />
              <p className="text-xs font-bold uppercase tracking-wider">Nenhum indicador selecionado</p>
            </div>
          )}
        </div>
      </div>

      {/* Goal Progress Chart */}
      <div className="bg-gradient-to-br from-white to-emerald-50/30 p-8 rounded-[32px] shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-lg transition-all duration-300">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-400 to-teal-600"></div>
        <div className="flex items-center gap-4 mb-2">
          <div className="p-3 bg-emerald-100 rounded-xl text-emerald-600">
            <Target className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-[#000C33]">Evolução das Metas</h3>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Percentual de Conclusão</p>
          </div>
        </div>
        
        <div className="h-80 w-full mt-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={goalChartData}
              layout="vertical"
              margin={{ top: 0, right: 30, left: 10, bottom: 0 }}
            >
              <defs>
                <linearGradient id="progGradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#002FC9" />
                  <stop offset="100%" stopColor="#60a5fa" />
                </linearGradient>
                <linearGradient id="completedGradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#009655" />
                  <stop offset="100%" stopColor="#4ade80" />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E2E8F0" />
              <XAxis 
                type="number" 
                domain={[0, maxProgress]} 
                axisLine={false} 
                tickLine={false}
                tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}}
                tickFormatter={(val) => `${val}%`}
              />
              <YAxis 
                dataKey="name" 
                type="category" 
                width={180} 
                axisLine={false} 
                tickLine={false} 
                tick={{fill: '#000C33', fontSize: 11, fontWeight: 600}} 
              />
              <Tooltip 
                content={<GoalTooltip />}
                cursor={{fill: '#F1F5F9', opacity: 0.5}} 
              />
              <Bar 
                dataKey="progress" 
                name="Progresso (%)" 
                radius={[0, 10, 10, 0] as [number, number, number, number]} 
                barSize={20}
                background={{ fill: '#F8FAFC', radius: [0, 10, 10, 0] as any }}
              >
                {goalChartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.progress >= 100 ? 'url(#completedGradient)' : 'url(#progGradient)'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default ChartsSection;
