
import React, { useState, useMemo } from 'react';
import { KPI } from '../types';
import { IconResolver, ICON_CATEGORIES } from '../utils/iconMap';
import { 
  ChevronDown, 
  ChevronUp, 
  Target, 
  TrendingUp, 
  Edit3, 
  Hash,
  DollarSign,
  Percent,
  Star,
  Search,
  Check,
  LayoutGrid,
  X
} from 'lucide-react';

interface KPIFormModalProps {
  initialData: KPI | null;
  onSave: (kpi: KPI) => void;
  onDelete?: () => void;
  onClose: () => void;
}

const KPIFormModal: React.FC<KPIFormModalProps> = ({ initialData, onSave, onDelete, onClose }) => {
  const [formData, setFormData] = useState<Partial<KPI>>(initialData || {
    name: '',
    value: 0,
    target: 0,
    unit: 'number',
    trend: 'up',
    icon: 'Hash',
    chartVisible: true
  });
  
  const [iconSelectorOpen, setIconSelectorOpen] = useState(false);
  const [iconSearch, setIconSearch] = useState('');
  const [activeTab, setActiveTab] = useState<string>(Object.keys(ICON_CATEGORIES)[0]);

  // Theme based on edit/create
  const isEditing = !!initialData;
  const theme = {
    headerGradient: 'from-[#002FC9] to-[#000C33]',
  };

  const handleSave = () => {
    if (!formData.name) return;
    const kpiToSave = {
        id: initialData?.id || '',
        name: formData.name,
        value: Number(formData.value),
        target: Number(formData.target),
        unit: formData.unit || 'number',
        trend: formData.trend || 'up',
        icon: formData.icon || 'Hash',
        chartVisible: formData.chartVisible ?? true
    } as KPI;

    onSave(kpiToSave);
  };

  const adjustValue = (field: 'value' | 'target', factor: number) => {
    const currentVal = Number(formData[field]) || 0;
    const step = formData.unit === 'currency' ? 100 : formData.unit === 'rating' ? 0.1 : 1;
    const newVal = currentVal + (step * factor);
    setFormData(prev => ({ ...prev, [field]: parseFloat(newVal.toFixed(2)) }));
  };

  // Filtered Icons Logic
  const filteredIcons = useMemo(() => {
    // If search is active, search ALL categories
    if (iconSearch.length > 0) {
      const allIcons = Object.values(ICON_CATEGORIES).reduce((acc, group) => ({ ...acc, ...group }), {});
      return Object.keys(allIcons).filter(iconName => 
        iconName.toLowerCase().includes(iconSearch.toLowerCase())
      );
    }
    // Otherwise, return icons for active tab
    const categoryIcons = (ICON_CATEGORIES as any)[activeTab] || {};
    return Object.keys(categoryIcons);
  }, [iconSearch, activeTab]);

  return (
    <div className="fixed inset-0 bg-[#000C33]/80 z-[60] flex items-center justify-center backdrop-blur-md p-4 animate-in fade-in duration-300">
      <div className="bg-white rounded-[32px] w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col border border-white/20 max-h-[90vh]">
        
        {/* Header */}
        <div className={`px-8 py-6 relative overflow-visible bg-gradient-to-br ${theme.headerGradient} shrink-0`}>
          <div className="absolute top-0 right-0 w-40 h-40 bg-white opacity-10 blur-[50px] rounded-full translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>
          
          <div className="flex justify-between items-center relative z-10">
            <h3 className="text-white font-bold text-lg flex items-center gap-2">
              {isEditing ? <Edit3 className="w-5 h-5 text-white/90" /> : <Target className="w-5 h-5 text-white/90" />}
              {isEditing ? 'Editar Indicador' : 'Novo Indicador'}
            </h3>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors">&times;</button>
          </div>
          
          {/* Main Input Area (Integrated into Header) */}
          <div className="mt-6 flex items-center gap-4 relative z-10">
             <button 
                onClick={() => setIconSelectorOpen(!iconSelectorOpen)}
                className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-white border border-white/10 shadow-lg shrink-0 hover:bg-white/20 transition-all group relative"
             >
                <IconResolver iconName={formData.icon || 'Hash'} className="w-8 h-8" />
                <div className="absolute -bottom-2 bg-white text-[#002FC9] text-[9px] font-bold px-2 py-0.5 rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">Alterar Ícone</div>
             </button>
             <div className="w-full">
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Nome do KPI (Obrigatório)"
                  className="w-full bg-transparent text-2xl font-black text-white placeholder:text-white/30 border-b border-white/20 focus:border-white outline-none pb-1 transition-colors"
                  autoFocus={!isEditing}
                  required
                />
                <span className="text-white/60 text-xs font-medium uppercase tracking-wide mt-1 block">
                   {isEditing ? 'Atualizando métrica estratégica' : 'Definindo nova métrica estratégica'}
                </span>
             </div>
          </div>
        </div>
        
        {/* Body */}
        <div className="p-8 space-y-6 bg-[#F8FAFC] overflow-y-auto custom-scrollbar relative">
          
          {/* EXPANDABLE ICON SELECTOR (IMPROVED UI) */}
          {iconSelectorOpen && (
            <div className="mb-6 bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden animate-in slide-in-from-top-4 fade-in">
               {/* Search Header */}
               <div className="bg-white border-b border-slate-100 p-3 sticky top-0 z-20">
                 <div className="relative">
                   <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                   <input 
                     type="text" 
                     placeholder="Buscar por nome (ex: dinheiro, usuario)..." 
                     value={iconSearch}
                     onChange={(e) => setIconSearch(e.target.value)}
                     className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[#002FC9] focus:ring-2 focus:ring-[#002FC9]/10 transition-all font-medium text-[#000C33]"
                     autoFocus
                   />
                   {iconSearch && (
                     <button onClick={() => setIconSearch('')} className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600">
                       <X className="w-4 h-4" />
                     </button>
                   )}
                 </div>
               </div>
               
               {/* Categories Pills (Wrapped, No Scroll) */}
               {iconSearch.length === 0 && (
                 <div className="flex flex-wrap gap-2 p-3 bg-slate-50 border-b border-slate-100">
                   {Object.keys(ICON_CATEGORIES).map(cat => {
                      const isActive = activeTab === cat;
                      const shortName = cat.split('&')[0].trim();
                      
                      return (
                        <button
                          key={cat}
                          onClick={() => setActiveTab(cat)}
                          className={`px-3 py-1.5 text-[10px] font-bold rounded-full transition-all border ${
                            isActive 
                              ? 'bg-[#002FC9] text-white border-[#002FC9] shadow-md shadow-blue-500/20' 
                              : 'bg-white text-slate-500 border-slate-200 hover:border-blue-300 hover:text-blue-600'
                          }`}
                        >
                          {cat}
                        </button>
                      );
                   })}
                 </div>
               )}

               {/* Icon Grid (Responsive) */}
               <div className="h-64 overflow-y-auto p-4 custom-scrollbar bg-slate-50/30">
                 {filteredIcons.length === 0 ? (
                   <div className="text-center py-12 text-slate-400 flex flex-col items-center">
                      <LayoutGrid className="w-8 h-8 mb-2 opacity-20" />
                      <span className="text-sm font-medium">Nenhum ícone encontrado.</span>
                   </div>
                 ) : (
                   <div className="grid grid-cols-[repeat(auto-fill,minmax(3rem,1fr))] gap-3">
                     {filteredIcons.map(iconName => (
                       <button
                         key={iconName}
                         onClick={() => { setFormData({...formData, icon: iconName}); setIconSelectorOpen(false); }}
                         className={`aspect-square flex items-center justify-center rounded-xl transition-all group duration-200 ${
                           formData.icon === iconName 
                             ? 'bg-[#002FC9] text-white shadow-lg scale-110 ring-2 ring-offset-2 ring-[#002FC9]' 
                             : 'bg-white text-slate-400 hover:bg-white hover:text-[#002FC9] hover:shadow-md border border-slate-100 hover:-translate-y-0.5'
                         }`}
                         title={iconName}
                       >
                         <IconResolver iconName={iconName} className="w-6 h-6" />
                       </button>
                     ))}
                   </div>
                 )}
               </div>
               
               <div className="p-2 bg-white border-t border-slate-100 text-center">
                 <button onClick={() => setIconSelectorOpen(false)} className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-[#002FC9] transition-colors py-1 block w-full">Minimizar Seleção</button>
               </div>
            </div>
          )}

          {/* Values Row */}
          <div className="grid grid-cols-2 gap-5">
            <div>
               <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                 Realizado <span className="text-red-500">*</span>
               </label>
               <div className="relative group/input">
                 <input 
                   type="number" 
                   value={formData.value}
                   onChange={(e) => setFormData({...formData, value: parseFloat(e.target.value)})}
                   className="w-full px-4 py-3 pr-12 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:border-[#002FC9] focus:ring-4 focus:ring-[#002FC9]/10 font-bold text-[#000C33] text-lg shadow-sm transition-all"
                   required
                 />
                 <div className="absolute right-2 top-2 bottom-2 w-7 flex flex-col gap-1">
                    <button onClick={() => adjustValue('value', 1)} className="flex-1 bg-slate-50 hover:bg-slate-100 rounded flex items-center justify-center text-slate-400 hover:text-blue-600"><ChevronUp className="w-3 h-3" /></button>
                    <button onClick={() => adjustValue('value', -1)} className="flex-1 bg-slate-50 hover:bg-slate-100 rounded flex items-center justify-center text-slate-400 hover:text-blue-600"><ChevronDown className="w-3 h-3" /></button>
                 </div>
               </div>
            </div>
            <div>
               <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                 Meta / Limite <span className="text-red-500">*</span>
               </label>
               <div className="relative group/input">
                 <input 
                   type="number" 
                   value={formData.target}
                   onChange={(e) => setFormData({...formData, target: parseFloat(e.target.value)})}
                   className="w-full px-4 py-3 pr-12 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:border-[#002FC9] focus:ring-4 focus:ring-[#002FC9]/10 font-bold text-[#000C33] text-lg shadow-sm transition-all"
                   required
                 />
                 <div className="absolute right-2 top-2 bottom-2 w-7 flex flex-col gap-1">
                    <button onClick={() => adjustValue('target', 1)} className="flex-1 bg-slate-50 hover:bg-slate-100 rounded flex items-center justify-center text-slate-400 hover:text-blue-600"><ChevronUp className="w-3 h-3" /></button>
                    <button onClick={() => adjustValue('target', -1)} className="flex-1 bg-slate-50 hover:bg-slate-100 rounded flex items-center justify-center text-slate-400 hover:text-blue-600"><ChevronDown className="w-3 h-3" /></button>
                 </div>
               </div>
            </div>
          </div>

          {/* Config Row */}
          <div className="grid grid-cols-2 gap-5">
             <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                  Unidade <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-4 gap-2">
                   {[
                     { id: 'number', icon: Hash, label: 'Num' }, 
                     { id: 'currency', icon: DollarSign, label: 'R$' }, 
                     { id: 'percent', icon: Percent, label: '%' }, 
                     { id: 'rating', icon: Star, label: '0-5' }
                   ].map(opt => (
                     <button
                       key={opt.id}
                       onClick={() => setFormData({...formData, unit: opt.id as any})}
                       className={`flex flex-col items-center justify-center p-2 rounded-xl border-2 transition-all gap-1 ${formData.unit === opt.id ? 'border-[#002FC9] bg-blue-50 text-[#002FC9] shadow-sm' : 'border-slate-100 bg-white text-slate-400 hover:border-slate-200'}`}
                     >
                        <opt.icon className="w-4 h-4" />
                     </button>
                   ))}
                </div>
             </div>

             <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                  Tendência Ideal <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                   <button
                     onClick={() => setFormData({...formData, trend: 'up'})}
                     className={`flex flex-col items-center justify-center gap-1 p-2 rounded-xl border-2 transition-all text-xs font-bold ${formData.trend === 'up' ? 'border-[#009655] bg-emerald-50 text-[#009655] shadow-sm' : 'border-slate-100 bg-white text-slate-400 hover:border-slate-200'}`}
                   >
                      <TrendingUp className="w-4 h-4" /> Maior
                   </button>
                   <button
                     onClick={() => setFormData({...formData, trend: 'down'})}
                     className={`flex flex-col items-center justify-center gap-1 p-2 rounded-xl border-2 transition-all text-xs font-bold ${formData.trend === 'down' ? 'border-[#002FC9] bg-blue-50 text-[#002FC9] shadow-sm' : 'border-slate-100 bg-white text-slate-400 hover:border-slate-200'}`}
                   >
                      <TrendingUp className="w-4 h-4 rotate-180" /> Menor
                   </button>
                </div>
             </div>
          </div>
        </div>

        {/* Footer with Save/Cancel Only (Delete removed) */}
        <div className="bg-white px-8 py-6 flex justify-end items-center border-t border-slate-100 shrink-0">
          <div className="flex gap-3">
            <button onClick={onClose} className="px-6 py-3 text-slate-600 font-bold hover:bg-slate-50 rounded-xl transition-colors text-sm">Cancelar</button>
            <button 
              onClick={handleSave}
              disabled={!formData.name}
              className="px-8 py-3 bg-[#002FC9] text-white font-bold rounded-xl hover:bg-[#0025a0] shadow-lg shadow-blue-600/20 transition-all transform hover:-translate-y-0.5 text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Check className="w-4 h-4" /> {isEditing ? 'Salvar' : 'Criar'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KPIFormModal;
