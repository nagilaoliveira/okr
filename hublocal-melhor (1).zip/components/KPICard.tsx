
import React, { useMemo } from 'react';
import { KPI } from '../types';
import { IconResolver } from '../utils/iconMap';
import { TrendingUp, TrendingDown, Pencil, Trash2 } from 'lucide-react';

interface KPICardProps {
  kpi: KPI;
  canEdit: boolean;
  canDelete: boolean;
  onEdit: () => void;
  onDelete: () => void;
}

const KPICard: React.FC<KPICardProps> = ({ kpi, canEdit, canDelete, onEdit, onDelete }) => {
  // --- Lógica de Cálculo ---
  const isInverse = kpi.trend === 'down';
  
  // Cálculo do percentual visual (0 a 100)
  let progressPercent = 0;
  if (isInverse) {
    // Para KPIs invertidos (ex: Churn): 
    // Se valor <= meta, 100%. Se valor > meta, decresce proporcionalmente.
    if (kpi.value <= kpi.target) {
      progressPercent = 100;
    } else {
      // Ex: Meta 5, Valor 10. (5/10) * 100 = 50%
      progressPercent = Math.max(0, (kpi.target / kpi.value) * 100);
    }
  } else {
    // Padrão: (Valor / Meta) * 100
    progressPercent = Math.min(100, Math.max(0, (kpi.value / kpi.target) * 100));
  }

  // Determinar Status
  const getStatus = () => {
    // 1. Saudável (Meta Batida)
    const isSuccess = isInverse ? kpi.value <= kpi.target : kpi.value >= kpi.target;
    if (isSuccess) return 'success';

    // 2. Atenção (Próximo da meta - ex: > 75%)
    if (progressPercent > 75) return 'warning';

    // 3. Padrão (Longe da meta)
    return 'default';
  };

  const status = getStatus();

  // --- Temas Visuais (Atualizado: Gradiente Azul -> Verde) ---
  const THEMES = {
    success: {
      // Gradiente da marca: Azul Escuro (#002FC9) para Verde (#009655)
      borderGradient: 'from-[#002FC9] via-[#006090] to-[#009655]',
      bgGradient: 'from-blue-50/50 to-emerald-50/50',
      textGradient: 'from-[#002FC9] to-[#009655]',
      iconBg: 'bg-gradient-to-br from-[#002FC9] to-[#009655]',
      iconColor: 'text-white',
      badge: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      progressBar: 'bg-gradient-to-r from-[#002FC9] to-[#009655]',
      progressTrack: 'bg-slate-100',
      shadow: 'shadow-blue-900/10',
      glow: 'group-hover:shadow-emerald-500/20'
    },
    warning: {
      // Mantendo Violeta/Fúcsia para alertas (distinção visual)
      borderGradient: 'from-violet-500 via-fuchsia-500 to-pink-500',
      bgGradient: 'from-violet-50/80 to-white',
      textGradient: 'from-violet-600 to-fuchsia-600',
      iconBg: 'bg-gradient-to-br from-violet-500 to-fuchsia-600',
      iconColor: 'text-white',
      badge: 'bg-violet-100 text-violet-800 border-violet-200',
      progressBar: 'bg-gradient-to-r from-violet-500 to-fuchsia-500',
      progressTrack: 'bg-violet-100/50',
      shadow: 'shadow-violet-500/20',
      glow: 'group-hover:shadow-violet-500/30'
    },
    default: {
      // Gradiente Padrão também usa a identidade da marca
      borderGradient: 'from-[#002FC9] via-[#0055aa] to-[#008080]',
      bgGradient: 'from-blue-50/50 to-white',
      textGradient: 'from-[#002FC9] to-[#009655]', // Texto gradiente
      iconBg: 'bg-[#002FC9]',
      iconColor: 'text-white',
      badge: 'bg-blue-100 text-blue-700 border-blue-200',
      progressBar: 'bg-gradient-to-r from-[#002FC9] to-[#009655]', // Barra gradiente
      progressTrack: 'bg-slate-100',
      shadow: 'shadow-slate-200',
      glow: 'group-hover:shadow-blue-500/20'
    }
  };

  const theme = THEMES[status];

  // Formatadores
  const formatValue = (val: number, unit: string) => {
    if (unit === 'currency') {
      return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(val);
    }
    if (unit === 'percent') {
      return new Intl.NumberFormat('pt-BR', { style: 'decimal', minimumFractionDigits: 1, maximumFractionDigits: 2 }).format(val) + '%';
    }
    return new Intl.NumberFormat('pt-BR').format(val);
  };

  const targetLabel = isInverse ? 'Limite Máx.' : 'Meta Alvo';

  // Handlers
  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete();
  };

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onEdit();
  };

  return (
    <div 
      className={`group relative w-full h-full min-h-[220px] rounded-[24px] transition-all duration-500 ${(canEdit || canDelete) ? 'cursor-pointer hover:-translate-y-1' : ''}`}
      onClick={() => canEdit && onEdit()}
    >
      {/* 1. Borda Gradiente Animada (Background Layer) */}
      <div 
        className={`absolute -inset-[2px] rounded-[26px] bg-gradient-to-br ${theme.borderGradient} opacity-0 group-hover:opacity-100 blur-[3px] transition-opacity duration-500`} 
      />
      
      {/* 2. Conteúdo do Card */}
      <div className={`relative h-full bg-white rounded-[24px] p-6 flex flex-col justify-between border border-slate-100 group-hover:border-transparent transition-all duration-300 shadow-lg ${theme.shadow} ${theme.glow} overflow-hidden`}>
        
        {/* Background Decorativo Suave */}
        <div className={`absolute top-0 right-0 w-[150%] h-[150%] bg-gradient-to-br ${theme.bgGradient} opacity-30 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4 pointer-events-none transition-transform duration-700 group-hover:scale-110`} />

        {/* --- HEADER --- */}
        <div className="relative flex justify-between items-start z-10">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg shadow-black/5 ${theme.iconBg} ${theme.iconColor} transform transition-all duration-500 group-hover:scale-110 group-hover:rotate-3 ring-4 ring-white`}>
             <IconResolver iconName={kpi.icon} className="w-6 h-6 drop-shadow-md" />
          </div>
          
          <div className="flex flex-col items-end gap-2">
             {/* Botões de Ação (Aparecem no Hover) */}
             <div className="absolute -top-3 -right-3 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-2 group-hover:translate-x-0 z-20">
               {canEdit && (
                 <button 
                    onClick={handleEditClick}
                    className="p-2 bg-white text-blue-600 hover:bg-blue-50 border border-slate-100 rounded-xl shadow-sm transition-colors"
                    title="Editar KPI"
                 >
                   <Pencil className="w-3.5 h-3.5" />
                 </button>
               )}
               {canDelete && (
                 <button 
                    onClick={handleDeleteClick}
                    className="p-2 bg-white text-red-500 hover:bg-red-50 border border-slate-100 rounded-xl shadow-sm transition-colors"
                    title="Excluir KPI"
                 >
                   <Trash2 className="w-3.5 h-3.5" />
                 </button>
               )}
             </div>
             
             {/* Badge de Tendência */}
             <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border transition-colors ${theme.badge}`}>
                {kpi.trend === 'up' ? <TrendingUp className="w-3 h-3" strokeWidth={3} /> : <TrendingDown className="w-3 h-3" strokeWidth={3} />}
                {kpi.trend === 'up' ? 'Crescimento' : 'Redução'}
             </div>
          </div>
        </div>

        {/* --- BODY --- */}
        <div className="relative mt-5 z-10">
           <h3 className="text-slate-400 font-extrabold text-[10px] uppercase tracking-[0.2em] mb-1.5 truncate opacity-90">
             {kpi.name}
           </h3>
           <div className={`text-3xl md:text-[2.5rem] leading-none font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-br ${theme.textGradient} drop-shadow-sm transition-all duration-300 group-hover:scale-[1.02] origin-left`}>
             {formatValue(kpi.value, kpi.unit)}
           </div>
        </div>

        {/* --- FOOTER: Progress Bar --- */}
        <div className="relative mt-6 z-10">
           <div className="flex justify-between items-end mb-2">
              <div className="flex flex-col">
                 <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide opacity-80">{targetLabel}</span>
                 <span className="text-xs font-bold text-slate-600">{formatValue(kpi.target, kpi.unit)}</span>
              </div>
              <span className={`text-lg font-black ${theme.textGradient.split(' ')[1].replace('text-', 'text-transparent bg-clip-text bg-gradient-to-br ' + theme.textGradient)}`}>
                {Math.round(progressPercent)}%
              </span>
           </div>
           
           {/* Barra de Progresso Aprimorada (Mais grossa h-4) */}
           <div className={`h-4 w-full rounded-full overflow-hidden p-[2px] ${theme.progressTrack} shadow-inner`}>
              <div 
                className={`h-full rounded-full transition-all duration-1000 ease-out relative overflow-hidden ${theme.progressBar} shadow-[0_0_10px_rgba(0,0,0,0.1)]`}
                style={{ width: `${progressPercent}%` }}
              >
                {/* Efeito de Brilho/Reflexo */}
                <div className="absolute inset-0 w-full h-full bg-gradient-to-b from-white/30 to-transparent pointer-events-none"></div>
                
                {/* Efeito de Listras Animadas (para status de atenção) */}
                {status === 'warning' && (
                   <div className="absolute inset-0 w-full h-full bg-[linear-gradient(45deg,rgba(255,255,255,0.2)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.2)_50%,rgba(255,255,255,0.2)_75%,transparent_75%,transparent)] bg-[length:1rem_1rem] animate-[progress-stripes_2s_linear_infinite] opacity-30"></div>
                )}
              </div>
           </div>
        </div>

      </div>
      
      {/* Animation Style */}
      <style>{`
        @keyframes progress-stripes {
          0% { background-position: 1rem 0; }
          100% { background-position: 0 0; }
        }
      `}</style>
    </div>
  );
};

export default KPICard;
