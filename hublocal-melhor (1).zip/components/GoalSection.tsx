
import React, { useState, useEffect } from 'react';
import { Goal, CategoryConfig, StatusConfig, Milestone, CalculationType } from '../types';
import { IconResolver } from '../utils/iconMap';
import { 
  Plus, 
  CheckCircle2, 
  Trash2,
  TrendingUp,
  Flag,
  Target,
  AlignLeft,
  Layout,
  Calculator,
  ListChecks,
  AlertTriangle,
  Check,
  Info,
  Pencil,
  MousePointerClick,
  SlidersHorizontal,
  Wand2
} from 'lucide-react';

interface GoalSectionProps {
  goals: Goal[];
  categories: Record<string, CategoryConfig>;
  statuses?: Record<string, StatusConfig>; 
  canCreate: boolean;
  canEdit: boolean;
  canDelete: boolean;
  onUpdate: (goal: Goal) => void;
  onDelete: (goalId: string) => void;
  onAdd: (goal: Goal) => void;
}

// Helper Tooltip Component
const Tooltip = ({ content, children }: React.PropsWithChildren<{ content: string }>) => (
  <div className="group relative inline-flex">
    {children}
    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block w-48 p-2 bg-[#000C33] text-white text-[10px] font-medium rounded-lg shadow-xl z-50 text-center animate-in fade-in zoom-in-95 duration-200 pointer-events-none">
      {content}
      <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-[#000C33]"></div>
    </div>
  </div>
);

// Helper to generate styles dynamically based on theme color
const getThemeStyles = (color: string) => {
  return {
    borderLeft: `border-${color}-500`,
    text: `text-${color}-600`,
    bg: `bg-${color}-50`,
    bgHover: `hover:bg-${color}-50`,
    badge: `bg-${color}-100 text-${color}-700`,
    gradient: `from-${color}-500 to-${color}-600`
  };
};

const getStatusStyles = (color: string) => {
  const map: Record<string, string> = {
    blue: 'text-blue-600 bg-blue-50 border-blue-100',
    green: 'text-green-600 bg-green-50 border-green-100',
    red: 'text-red-600 bg-red-50 border-red-100',
    orange: 'text-orange-600 bg-orange-50 border-orange-100',
    purple: 'text-purple-600 bg-purple-50 border-purple-100',
    cyan: 'text-cyan-600 bg-cyan-50 border-cyan-100',
    slate: 'text-slate-500 bg-slate-50 border-slate-100',
    rose: 'text-rose-600 bg-rose-50 border-rose-100',
    emerald: 'text-emerald-600 bg-emerald-50 border-emerald-100',
    fuchsia: 'text-fuchsia-600 bg-fuchsia-50 border-fuchsia-100',
    lime: 'text-lime-600 bg-lime-50 border-lime-100',
    amber: 'text-amber-600 bg-amber-50 border-amber-100',
    violet: 'text-violet-600 bg-violet-50 border-violet-100',
  };
  return map[color] || map['slate'];
};

const GoalSection: React.FC<GoalSectionProps> = ({ goals, categories, statuses = {}, canCreate, canEdit, canDelete, onUpdate, onDelete, onAdd }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formState, setFormState] = useState<Partial<Goal>>({});

  const availableStatuses: Record<string, StatusConfig> = Object.keys(statuses).length > 0 ? statuses : {
    'Planejado': { id: 'Planejado', label: 'Planejado', colorTheme: 'slate', icon: 'Circle' }
  };

  const openAdd = () => {
    const defaultCat = Object.keys(categories)[0] || '';
    const defaultStatus = Object.keys(availableStatuses)[0] || 'Planejado';
    setFormState({ 
      title: '', 
      description: '', 
      progress: 0, 
      status: defaultStatus, 
      category: defaultCat,
      calculationType: 'manual',
      currentValue: 0,
      targetValue: 0,
      milestones: []
    });
    setEditingId(null);
    setIsAdding(true);
  };

  const openEdit = (goal: Goal) => {
    setFormState({
      ...goal,
      calculationType: goal.calculationType || 'manual',
      currentValue: goal.currentValue || 0,
      targetValue: goal.targetValue || 0,
      milestones: goal.milestones || []
    });
    setEditingId(goal.id);
    setIsAdding(true);
  };

  useEffect(() => {
    if (!isAdding) return;

    let calculatedProgress = formState.progress || 0;

    if (formState.calculationType === 'quantitative') {
      const curr = formState.currentValue || 0;
      const target = formState.targetValue || 1;
      if (target > 0) {
        calculatedProgress = Math.min(100, Math.max(0, (curr / target) * 100));
      }
    } else if (formState.calculationType === 'milestone') {
      const completedWeight = (formState.milestones || [])
        .filter(m => m.completed)
        .reduce((sum, m) => sum + m.weight, 0);
      calculatedProgress = Math.min(100, Math.max(0, completedWeight));
    }

    const rounded = parseFloat(calculatedProgress.toFixed(1));
    if (rounded !== formState.progress) {
      setFormState(prev => ({ ...prev, progress: rounded }));
    }
  }, [formState.currentValue, formState.targetValue, formState.milestones, formState.calculationType, isAdding]);


  const handleSubmit = () => {
    if (!formState.title || !formState.description) return;
    
    if (formState.calculationType === 'milestone') {
        const totalWeight = (formState.milestones || []).reduce((sum, m) => sum + m.weight, 0);
        if (Math.abs(totalWeight - 100) > 0.1) {
            alert(`A soma dos pesos dos marcos deve ser 100%. Atual: ${totalWeight}%`);
            return;
        }
    }

    if (editingId) {
      onUpdate(formState as Goal);
    } else {
      onAdd({ ...formState, id: `goal-${Date.now()}` } as Goal);
    }
    setIsAdding(false);
  };

  const handleCardDelete = (e: React.MouseEvent, goalId: string) => {
    e.stopPropagation();
    onDelete(goalId);
  };

  // Milestone Helpers
  const addMilestone = () => {
    const newMs: Milestone = {
        id: `ms-${Date.now()}`,
        label: 'Nova Etapa',
        weight: 0,
        completed: false
    };
    setFormState(prev => ({
        ...prev,
        milestones: [...(prev.milestones || []), newMs]
    }));
  };

  const distributeWeights = () => {
    const milestones = formState.milestones || [];
    if (milestones.length === 0) return;

    const count = milestones.length;
    const baseWeight = Math.floor(100 / count);
    const remainder = 100 % count;

    const newMilestones = milestones.map((ms, index) => ({
      ...ms,
      // Add remainder to the first items
      weight: baseWeight + (index < remainder ? 1 : 0)
    }));

    setFormState(prev => ({ ...prev, milestones: newMilestones }));
  };

  const updateMilestone = (id: string, field: keyof Milestone, value: any) => {
    setFormState(prev => ({
        ...prev,
        milestones: (prev.milestones || []).map(m => m.id === id ? { ...m, [field]: value } : m)
    }));
  };

  const removeMilestone = (id: string) => {
    setFormState(prev => ({
        ...prev,
        milestones: (prev.milestones || []).filter(m => m.id !== id)
    }));
  };

  const totalMilestoneWeight = (formState.milestones || []).reduce((acc, curr) => acc + curr.weight, 0);
  const isWeightValid = Math.abs(totalMilestoneWeight - 100) < 0.1;

  // Improved Calculation Type Card
  const CalculationTypeCard = ({ 
    type, 
    label, 
    description, 
    icon: Icon,
    current 
  }: { 
    type: CalculationType, 
    label: string, 
    description: string, 
    icon: any,
    current: CalculationType 
  }) => {
    const isSelected = current === type;
    return (
      <label 
        className={`flex-1 relative cursor-pointer group p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center text-center gap-2 ${
          isSelected 
            ? 'border-[#002FC9] bg-blue-50/50 shadow-md ring-1 ring-[#002FC9]/20' 
            : 'border-slate-100 bg-white hover:border-blue-200 hover:shadow-sm'
        }`}
      >
        <div className={`p-3 rounded-full transition-colors ${isSelected ? 'bg-[#002FC9] text-white' : 'bg-slate-100 text-slate-400 group-hover:text-[#002FC9]'}`}>
           <Icon className="w-5 h-5" />
        </div>
        <div>
          <span className={`block text-sm font-bold mb-1 ${isSelected ? 'text-[#002FC9]' : 'text-slate-600'}`}>
            {label}
          </span>
          <span className={`block text-[10px] font-medium leading-tight ${isSelected ? 'text-[#002FC9]/70' : 'text-slate-400'}`}>
            {description}
          </span>
        </div>
        <input 
          type="radio" 
          name="calcType" 
          value={type} 
          checked={isSelected}
          onChange={() => setFormState({...formState, calculationType: type})}
          className="hidden"
        />
      </label>
    );
  };

  return (
    <section className="bg-white rounded-[32px] p-8 shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-slate-100">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-black text-[#000C33] flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-[#002FC9]"></span>
            Metas Operacionais
          </h2>
          <p className="text-[#000C33]/40 text-sm font-bold ml-6 mt-1 uppercase tracking-widest">Iniciativas & Projetos</p>
        </div>
        {canCreate && (
          <button 
            onClick={openAdd}
            className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 text-white text-xs font-bold uppercase tracking-wider rounded-xl hover:bg-[#002FC9] transition-all transform hover:-translate-y-1 shadow-lg shadow-slate-900/10"
          >
            <Plus className="w-4 h-4" />
            Nova Meta
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {goals.map((goal) => {
          const catConfig = categories[goal.category] || categories[Object.keys(categories)[0]];
          const statusConfig = statuses?.[goal.status] || { label: goal.status, colorTheme: 'slate', icon: 'Circle' } as StatusConfig;
          
          const catStyles = getThemeStyles(catConfig?.colorTheme || 'slate');
          const statusStyles = getStatusStyles(statusConfig.colorTheme);
          
          let detailsInfo = null;
          if (goal.calculationType === 'quantitative') {
             detailsInfo = (
                 <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded">
                    {goal.currentValue} / {goal.targetValue} {goal.metricUnit}
                 </span>
             );
          } 
          // Removed specific "Prox: ..." for milestones as requested

          return (
            <div 
              key={goal.id} 
              onClick={() => canEdit && openEdit(goal)}
              className={`bg-white rounded-xl p-5 border border-slate-100 shadow-sm transition-all duration-300 relative overflow-hidden border-l-[6px] ${catStyles.borderLeft} ${canEdit ? 'hover:shadow-xl cursor-pointer group hover:-translate-y-1' : 'opacity-90 cursor-default'}`}
            >
              <div className="flex justify-between items-start mb-3">
                 <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-widest ${catStyles.badge}`}>
                    <IconResolver iconName={catConfig?.icon || 'Target'} className="w-3 h-3" />
                    {catConfig?.label || goal.category}
                 </div>
                 <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {canEdit && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); openEdit(goal); }} 
                        className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-blue-500 transition-colors"
                        title="Editar"
                      >
                          <Pencil className="w-4 h-4" />
                      </button>
                    )}
                    {canDelete && (
                      <button 
                        onClick={(e) => handleCardDelete(e, goal.id)} 
                        className="p-1.5 hover:bg-red-50 rounded-lg text-slate-400 hover:text-red-500 transition-colors"
                        title="Excluir"
                      >
                          <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                 </div>
              </div>

              <div className="mb-6">
                <h3 className="font-bold text-slate-800 text-lg leading-tight mb-2 group-hover:text-[#002FC9] transition-colors line-clamp-2">
                   {goal.title}
                </h3>
                <p className="text-slate-500 text-xs leading-relaxed line-clamp-2 font-medium">
                  {goal.description}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-50 flex items-center justify-between gap-4">
                 <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] font-bold uppercase tracking-wide ${statusStyles}`}>
                    <IconResolver iconName={statusConfig.icon} className="w-3 h-3" />
                    <span className="truncate max-w-[80px]">{statusConfig.label}</span>
                 </div>
                 
                 <div className="flex flex-col items-end gap-1 flex-1 min-w-0">
                    <div className="flex items-center gap-2 w-full justify-end">
                        {detailsInfo}
                        <span className="text-xs font-black text-transparent bg-clip-text bg-gradient-to-r from-[#002FC9] to-[#009655]">
                          {Math.round(goal.progress)}%
                        </span>
                    </div>
                    {/* Increased thickness to h-3 */}
                    <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden max-w-[100px]">
                       <div 
                         className="h-full rounded-full bg-gradient-to-r from-[#002FC9] to-[#009655]" 
                         style={{ width: `${Math.min(goal.progress, 100)}%` }}
                        ></div>
                    </div>
                 </div>
              </div>
            </div>
          );
        })}

        {canCreate && (
          <button 
            onClick={openAdd}
            className="min-h-[200px] border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center gap-3 text-slate-400 hover:text-[#002FC9] hover:border-[#002FC9] hover:bg-blue-50/50 transition-all group"
          >
            <div className="w-12 h-12 rounded-full bg-slate-50 group-hover:bg-white flex items-center justify-center transition-colors shadow-sm">
              <Plus className="w-6 h-6" />
            </div>
            <span className="text-sm font-bold uppercase tracking-wide">Adicionar Meta</span>
          </button>
        )}
      </div>

      {isAdding && canEdit && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-[32px] w-full max-w-3xl shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh] overflow-hidden">
            <div className="bg-[#000C33] px-8 py-6 flex justify-between items-center relative overflow-hidden shrink-0">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#002FC9] opacity-30 blur-[50px] rounded-full translate-x-1/2 -translate-y-1/2"></div>
              
              <h3 className="text-white font-bold text-lg flex items-center gap-2 relative z-10">
                <Target className="w-5 h-5 text-[#002FC9]" />
                {editingId ? 'Editar Meta' : 'Nova Meta'}
              </h3>
              <button onClick={() => setIsAdding(false)} className="text-white/50 hover:text-white text-2xl transition-colors relative z-10">&times;</button>
            </div>
            
            <div className="p-8 space-y-6 overflow-y-auto bg-[#f8fafc]">
              
              {/* Title & Description Group */}
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-1">
                    <Flag className="w-3 h-3" /> Título da Iniciativa <span className="text-red-500">*</span>
                  </label>
                  <input 
                    className="w-full text-xl font-black text-[#000C33] bg-transparent border-b-2 border-slate-100 focus:border-[#002FC9] outline-none placeholder:text-slate-300 transition-colors pb-2" 
                    value={formState.title} 
                    onChange={e => setFormState({...formState, title: e.target.value})}
                    placeholder="Ex: Contratar 3 SDRs"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-5">
                  <div>
                    <label className="label flex items-center gap-1.5">
                      <Layout className="w-3 h-3" /> Categoria
                    </label>
                    <div className="relative">
                      <select 
                        className="input appearance-none bg-white font-bold text-[#000C33]" 
                        value={formState.category}
                        onChange={e => setFormState({...formState, category: e.target.value})}
                      >
                        {Object.values(categories).map((config: CategoryConfig) => (
                          <option key={config.id} value={config.id}>{config.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="label flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3" /> Status
                    </label>
                    <select 
                      className="input appearance-none bg-white font-bold text-[#000C33]"
                      value={formState.status}
                      onChange={e => setFormState({...formState, status: e.target.value})}
                    >
                      {Object.values(availableStatuses).map((s: StatusConfig) => <option key={s.id} value={s.id}>{s.label}</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="label flex items-center gap-1.5">
                    <AlignLeft className="w-3 h-3" /> Descrição Detalhada
                  </label>
                  <textarea 
                    className="input min-h-[80px] bg-slate-50 border-slate-200 resize-none font-medium" 
                    value={formState.description}
                    onChange={e => setFormState({...formState, description: e.target.value})}
                    placeholder="Detalhes sobre a meta, responsáveis e critérios de sucesso..."
                    required
                  />
                </div>
              </div>

              {/* CALCULATION TYPE SELECTOR */}
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-6">
                 <div className="flex items-center gap-4 mb-4">
                    <div className="p-2 bg-blue-50 rounded-lg text-[#002FC9]">
                        <Calculator className="w-5 h-5" />
                    </div>
                    <div>
                        <label className="text-sm font-bold text-[#000C33]">Método de Cálculo</label>
                        <p className="text-[10px] text-slate-400">Como o progresso será medido?</p>
                    </div>
                 </div>

                 <div className="flex flex-col md:flex-row gap-4">
                    <CalculationTypeCard 
                      type="manual"
                      label="Manual"
                      description="Ajuste livre via slider"
                      icon={MousePointerClick}
                      current={formState.calculationType || 'manual'}
                    />
                    <CalculationTypeCard 
                      type="quantitative"
                      label="Linear"
                      description="Automático: Valor / Meta"
                      icon={SlidersHorizontal}
                      current={formState.calculationType || 'manual'}
                    />
                    <CalculationTypeCard 
                      type="milestone"
                      label="Etapas"
                      description="Soma dos pesos concluídos"
                      icon={ListChecks}
                      current={formState.calculationType || 'manual'}
                    />
                 </div>

                 {/* CONDITIONAL INPUTS BASED ON TYPE */}
                 <div className="min-h-[120px] pt-4 border-t border-slate-50">
                 
                 {/* MANUAL MODE */}
                 {formState.calculationType === 'manual' && (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <div className="flex justify-between items-end mb-4">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-[#002FC9]" />
                            Progresso Realizado
                        </label>
                        <div className="flex items-center gap-1">
                            <input
                                type="number"
                                min="0"
                                max="100"
                                value={formState.progress}
                                onChange={e => setFormState({...formState, progress: Math.max(0, parseInt(e.target.value) || 0)})}
                                className="text-4xl font-black tracking-tight text-[#002FC9] bg-transparent border-b-2 border-transparent hover:border-slate-200 focus:border-[#002FC9] focus:outline-none w-24 text-right transition-colors appearance-none m-0 p-0"
                            />
                            <span className="text-4xl font-black text-[#002FC9]">%</span>
                        </div>
                        </div>
                        <div className="relative h-6 w-full rounded-full bg-slate-100 inner-shadow overflow-hidden">
                            <div 
                                className="absolute top-0 left-0 h-full rounded-full transition-all duration-300 ease-out bg-gradient-to-r from-[#002FC9] to-[#009655]"
                                style={{ 
                                    width: `${Math.min(formState.progress || 0, 100)}%`
                                }}
                            ></div>
                            <input 
                                type="range" 
                                min="0" 
                                max="100" 
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                                value={Math.min(formState.progress || 0, 100)}
                                onChange={e => setFormState({...formState, progress: parseInt(e.target.value)})}
                            />
                        </div>
                    </div>
                 )}

                 {/* QUANTITATIVE MODE */}
                 {formState.calculationType === 'quantitative' && (
                     <div className="grid grid-cols-3 gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <div>
                            <label className="label">Valor Realizado</label>
                            <input 
                                type="number" 
                                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl text-[#000C33] font-bold outline-none focus:border-[#002FC9] focus:ring-4 focus:ring-[#002FC9]/10 transition-all placeholder:text-slate-300"
                                value={formState.currentValue}
                                onChange={e => setFormState({...formState, currentValue: parseFloat(e.target.value)})}
                            />
                        </div>
                        <div>
                            <label className="label">Meta Total</label>
                            <input 
                                type="number" 
                                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl text-[#000C33] font-bold outline-none focus:border-[#002FC9] focus:ring-4 focus:ring-[#002FC9]/10 transition-all placeholder:text-slate-300"
                                value={formState.targetValue}
                                onChange={e => setFormState({...formState, targetValue: parseFloat(e.target.value)})}
                            />
                        </div>
                        <div>
                            {/* Removed (opcional) label */}
                            <label className="label">Unidade</label>
                            <input 
                                type="text" 
                                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl text-[#000C33] font-bold outline-none focus:border-[#002FC9] focus:ring-4 focus:ring-[#002FC9]/10 transition-all placeholder:text-slate-300"
                                value={formState.metricUnit || ''}
                                onChange={e => setFormState({...formState, metricUnit: e.target.value})}
                                placeholder="ex: un, R$ (opcional)"
                            />
                        </div>
                        <div className="col-span-3 bg-blue-50 p-3 rounded-xl border border-blue-100 flex items-center justify-between">
                            <span className="text-xs font-bold text-blue-700 uppercase">Cálculo Automático:</span>
                            <span className="text-xl font-black text-[#002FC9]">{formState.progress?.toFixed(1)}%</span>
                        </div>
                     </div>
                 )}

                 {/* MILESTONE MODE */}
                 {formState.calculationType === 'milestone' && (
                     <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <div className="flex justify-between items-center px-1">
                            <div className="flex items-center gap-2">
                                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                                    <ListChecks className="w-4 h-4 text-[#002FC9]" /> 
                                    Etapas do Projeto
                                </label>
                            </div>
                            <div className="flex gap-2">
                                {/* Auto Distribute Button */}
                                {(formState.milestones || []).length > 0 && (
                                  <button onClick={distributeWeights} className="text-[10px] font-bold uppercase text-slate-600 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1">
                                      <Wand2 className="w-3 h-3" /> Distribuir %
                                  </button>
                                )}
                                <button onClick={addMilestone} className="text-[10px] font-bold uppercase text-[#002FC9] bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1">
                                    <Plus className="w-3 h-3" /> Nova Etapa
                                </button>
                            </div>
                        </div>
                        
                        <div className="bg-slate-50/50 rounded-2xl border border-slate-100 overflow-hidden">
                            {formState.milestones?.map((ms, idx) => (
                                <div key={ms.id} className="flex items-center gap-3 p-3 bg-white border-b border-slate-100 last:border-0 hover:bg-slate-50/80 transition-colors group">
                                    {/* Checkbox */}
                                    <label className="relative flex items-center justify-center cursor-pointer">
                                        <input 
                                            type="checkbox" 
                                            checked={ms.completed}
                                            onChange={(e) => updateMilestone(ms.id, 'completed', e.target.checked)}
                                            className="peer appearance-none w-5 h-5 border-2 border-slate-200 rounded-full checked:bg-[#009655] checked:border-[#009655] transition-all hover:border-blue-400"
                                        />
                                        <Check className="absolute w-3 h-3 text-white opacity-0 peer-checked:opacity-100 pointer-events-none transition-all scale-50 peer-checked:scale-100" strokeWidth={3} />
                                    </label>

                                    {/* Name */}
                                    <input 
                                        type="text" 
                                        value={ms.label}
                                        onChange={(e) => updateMilestone(ms.id, 'label', e.target.value)}
                                        placeholder={`Nome da etapa ${idx + 1}`}
                                        className="flex-1 bg-transparent text-sm font-semibold text-[#000C33] placeholder:text-slate-300 focus:outline-none focus:placeholder:text-blue-200/50"
                                    />
                                    
                                    {/* Weight */}
                                    <div className="flex items-center gap-2">
                                        <div className="relative group/weight">
                                            <input 
                                                type="number" 
                                                value={ms.weight}
                                                onChange={(e) => updateMilestone(ms.id, 'weight', parseFloat(e.target.value))}
                                                className="w-16 pl-3 pr-6 py-1.5 bg-white border border-slate-200 rounded-lg text-right text-xs font-bold text-[#000C33] outline-none focus:border-[#002FC9] focus:ring-2 focus:ring-[#002FC9]/10 transition-all placeholder:text-slate-200 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                                placeholder="0"
                                            />
                                            <span className="absolute right-2 top-1.5 text-[10px] font-bold text-slate-400 pointer-events-none">%</span>
                                        </div>
                                        
                                        <button onClick={() => removeMilestone(ms.id)} className="text-slate-300 hover:text-red-500 transition-colors p-1.5 hover:bg-red-50 rounded-lg opacity-0 group-hover:opacity-100">
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            ))}
                            {(!formState.milestones || formState.milestones.length === 0) && (
                                <div className="p-8 text-center flex flex-col items-center justify-center text-slate-400 gap-2">
                                    <ListChecks className="w-8 h-8 opacity-20" />
                                    <span className="text-xs font-medium">Nenhuma etapa definida</span>
                                    <button onClick={addMilestone} className="text-xs font-bold text-[#002FC9] hover:underline">Adicionar a primeira etapa</button>
                                </div>
                            )}
                        </div>

                        {/* Compact Weight Validation */}
                        <div className={`flex items-center justify-between px-4 py-3 rounded-xl border transition-all duration-300 ${isWeightValid ? 'bg-emerald-50/50 border-emerald-100' : 'bg-amber-50/50 border-amber-100'}`}>
                            <div className="flex items-center gap-3">
                                <div className={`p-1.5 rounded-full ${isWeightValid ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                                    {isWeightValid ? <Check className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
                                </div>
                                <div className="flex flex-col">
                                    <span className={`text-[10px] font-bold uppercase tracking-wider ${isWeightValid ? 'text-emerald-700' : 'text-amber-700'}`}>
                                        {isWeightValid ? 'Distribuição Correta' : 'Atenção nos Pesos'}
                                    </span>
                                    {!isWeightValid && (
                                        <span className="text-[10px] text-amber-600/80 font-medium">A soma deve ser 100%</span>
                                    )}
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className="text-[10px] font-bold text-slate-400 uppercase">Total:</span>
                                <span className={`text-lg font-black ${isWeightValid ? 'text-emerald-600' : 'text-amber-600'}`}>
                                    {totalMilestoneWeight}%
                                </span>
                            </div>
                        </div>
                     </div>
                 )}
                 </div>

              </div>
            </div>

            <div className="bg-white px-8 py-6 flex items-center justify-between border-t border-slate-100 shrink-0">
              <div>
                
              </div>
              <div className="flex gap-3">
                <button onClick={() => setIsAdding(false)} className="px-6 py-3 text-slate-600 font-bold hover:bg-slate-50 rounded-xl transition-colors text-sm">Cancelar</button>
                <button onClick={handleSubmit} className="px-6 py-3 bg-[#002FC9] text-white font-bold rounded-xl hover:bg-[#0025a0] shadow-lg shadow-[#002FC9]/20 transition-all transform hover:-translate-y-1 text-sm">Salvar Meta</button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <style>{`
        .label { display: block; font-size: 0.7rem; font-weight: 800; color: #94a3b8; margin-bottom: 0.5rem; text-transform: uppercase; letter-spacing: 0.05em; }
        .input { width: 100%; padding: 0.75rem 1rem; border: 2px solid #e2e8f0; border-radius: 0.75rem; font-size: 0.9rem; font-weight: 600; color: #000C33; background-color: #ffffff; transition: all 0.2s; }
        .input:focus { outline: none; border-color: #002FC9; background-color: #fff; box-shadow: 0 0 0 4px rgba(0, 47, 201, 0.05); }
        /* Remove arrows from number input */
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
          -webkit-appearance: none; 
          margin: 0; 
        }
      `}</style>
    </section>
  );
};

export default GoalSection;
