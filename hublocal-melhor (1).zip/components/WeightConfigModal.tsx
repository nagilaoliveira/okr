
import React, { useState } from 'react';
import { DepartmentData, WeightConfig } from '../types';
import { Save, AlertCircle, ChevronUp, ChevronDown, Scale } from 'lucide-react';

interface WeightConfigModalProps {
  data: DepartmentData;
  weights: WeightConfig;
  onSave: (newWeights: WeightConfig) => void;
  onClose: () => void;
}

const WeightConfigModal: React.FC<WeightConfigModalProps> = ({ data, weights, onSave, onClose }) => {
  const [localWeights, setLocalWeights] = useState<WeightConfig>(JSON.parse(JSON.stringify(weights)));

  const handleKpiWeightChange = (id: string, val: number) => {
    setLocalWeights(prev => ({
      ...prev,
      kpis: { ...prev.kpis, [id]: val }
    }));
  };

  const handleGoalWeightChange = (id: string, val: number) => {
    setLocalWeights(prev => ({
      ...prev,
      goals: { ...prev.goals, [id]: val }
    }));
  };

  const totalKpiSub = (Object.values(localWeights.kpis) as number[]).reduce((a, b) => a + b, 0);
  const totalGoalSub = (Object.values(localWeights.goals) as number[]).reduce((a, b) => a + b, 0);
  const totalMain = localWeights.kpiWeight + localWeights.goalWeight;

  const isValid = Math.abs(totalMain - 100) < 0.1 && 
                  Math.abs(totalKpiSub - localWeights.kpiWeight) < 0.1 && 
                  Math.abs(totalGoalSub - localWeights.goalWeight) < 0.1;

  // Componente de Input Customizado
  const CustomNumberInput = ({ value, onChange, max = 100, colorClass = "border-[#002FC9]" }: { value: number, onChange: (val: number) => void, max?: number, colorClass?: string }) => {
    const handleIncrement = () => onChange(Math.min(max, value + 0.5));
    const handleDecrement = () => onChange(Math.max(0, value - 0.5));

    return (
      <div className="relative group w-full">
        <input 
          type="number" 
          value={value}
          onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
          className={`w-full pl-4 pr-10 py-2.5 bg-white border-2 rounded-xl text-lg font-bold text-[#000C33] focus:outline-none focus:ring-4 focus:ring-opacity-20 transition-all shadow-sm [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${colorClass}`}
        />
        <div className="absolute right-1 top-1 bottom-1 w-8 flex flex-col gap-0.5">
          <button 
            type="button"
            onClick={handleIncrement}
            className="flex-1 bg-slate-50 hover:bg-slate-200 rounded-t-md flex items-center justify-center text-slate-500 hover:text-[#002FC9] transition-colors active:bg-slate-300"
            tabIndex={-1}
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
          <button 
            type="button"
            onClick={handleDecrement}
            className="flex-1 bg-slate-50 hover:bg-slate-200 rounded-b-md flex items-center justify-center text-slate-500 hover:text-[#002FC9] transition-colors active:bg-slate-300"
            tabIndex={-1}
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-[#000C33]/80 z-50 flex items-center justify-center backdrop-blur-md p-4 animate-in fade-in">
      <div className="bg-white rounded-[32px] w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-white shrink-0">
          <div>
            <h3 className="font-black text-2xl text-[#000C33] flex items-center gap-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Scale className="w-6 h-6 text-[#002FC9]" />
              </div>
              Configuração de Pesos
            </h3>
            <p className="text-sm text-slate-500 font-medium mt-1">Defina a importância de cada métrica no cálculo geral.</p>
          </div>
          <button 
            onClick={onClose} 
            className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-50 text-slate-400 hover:bg-red-50 hover:text-red-500 transition-colors font-bold text-xl"
          >
            &times;
          </button>
        </div>

        <div className="p-8 overflow-y-auto space-y-8 bg-[#f8fafc]">
          
          {/* Main Split */}
          <div className="bg-gradient-to-br from-[#EDF1FF] to-white p-6 rounded-2xl border border-[#002FC9]/10 shadow-sm">
            <h4 className="font-bold text-[#000C33] mb-4 flex items-center gap-2 text-lg">
              <span className="w-2 h-2 rounded-full bg-[#002FC9]"></span>
              Divisão Macro (Total: {totalMain}%)
            </h4>
            <div className="grid grid-cols-2 gap-8">
              <div>
                <label className="block text-[10px] font-bold text-[#002FC9] uppercase tracking-widest mb-2">Peso KPIs</label>
                <CustomNumberInput 
                  value={localWeights.kpiWeight} 
                  onChange={(val) => setLocalWeights({...localWeights, kpiWeight: val})} 
                  colorClass="border-[#002FC9]/20 focus:border-[#002FC9] focus:ring-[#002FC9]"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-[#009655] uppercase tracking-widest mb-2">Peso Metas</label>
                <CustomNumberInput 
                  value={localWeights.goalWeight} 
                  onChange={(val) => setLocalWeights({...localWeights, goalWeight: val})}
                  colorClass="border-[#009655]/20 focus:border-[#009655] focus:ring-[#009655]"
                />
              </div>
            </div>
          </div>

          {/* KPIs */}
          <div>
            <div className="flex justify-between items-center mb-4 px-1">
              <h4 className="font-bold text-[#000C33] text-lg flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                Pesos dos KPIs
              </h4>
              <span className={`text-xs font-bold px-3 py-1.5 rounded-lg border ${Math.abs(totalKpiSub - localWeights.kpiWeight) < 0.1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-600 border-red-200'}`}>
                Soma: {totalKpiSub.toFixed(1)}% / Meta: {localWeights.kpiWeight}%
              </span>
            </div>
            <div className="space-y-3">
              {data.kpis.map(kpi => (
                <div key={kpi.id} className="flex items-center gap-4 bg-white p-3 pr-4 rounded-xl shadow-sm border border-slate-100 hover:border-blue-100 transition-colors">
                  <span className="flex-1 text-sm font-bold text-[#000C33] truncate pl-2">{kpi.name}</span>
                  <div className="w-32">
                    <CustomNumberInput 
                      value={localWeights.kpis[kpi.id] || 0} 
                      onChange={(val) => handleKpiWeightChange(kpi.id, val)}
                      colorClass="border-slate-200 focus:border-[#002FC9]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Goals */}
          <div>
            <div className="flex justify-between items-center mb-4 px-1">
              <h4 className="font-bold text-[#000C33] text-lg flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                Pesos das Metas
              </h4>
              <span className={`text-xs font-bold px-3 py-1.5 rounded-lg border ${Math.abs(totalGoalSub - localWeights.goalWeight) < 0.1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-600 border-red-200'}`}>
                Soma: {totalGoalSub.toFixed(1)}% / Meta: {localWeights.goalWeight}%
              </span>
            </div>
            <div className="space-y-3">
              {data.goals.map(goal => (
                <div key={goal.id} className="flex items-center gap-4 bg-white p-3 pr-4 rounded-xl shadow-sm border border-slate-100 hover:border-blue-100 transition-colors">
                  <span className="flex-1 text-sm font-bold text-[#000C33] truncate pl-2">{goal.title}</span>
                  <div className="w-32">
                    <CustomNumberInput 
                      value={localWeights.goals[goal.id] || 0} 
                      onChange={(val) => handleGoalWeightChange(goal.id, val)}
                      colorClass="border-slate-200 focus:border-[#009655]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        <div className="p-6 bg-white border-t border-slate-100 flex justify-between items-center shrink-0">
          {!isValid ? (
            <div className="flex items-center gap-2 text-red-600 text-xs font-bold bg-red-50 px-4 py-3 rounded-xl border border-red-100">
              <AlertCircle className="w-4 h-4" />
              A soma dos pesos não bate com o total.
            </div>
          ) : <div className="text-xs font-bold text-emerald-600 bg-emerald-50 px-4 py-3 rounded-xl border border-emerald-100">Pesos balanceados corretamente.</div>}
          
          <div className="flex gap-3">
             <button onClick={onClose} className="px-6 py-3 text-[#000C33] font-bold hover:bg-[#EDF1FF] rounded-xl transition-colors text-sm">Cancelar</button>
             <button 
               onClick={() => onSave(localWeights)} 
               disabled={!isValid}
               className="px-6 py-3 bg-[#002FC9] text-white font-bold rounded-xl hover:bg-[#0025a0] disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-lg shadow-[#002FC9]/20 transform active:scale-95 transition-all text-sm"
             >
               <Save className="w-4 h-4" />
               Salvar Pesos
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeightConfigModal;
