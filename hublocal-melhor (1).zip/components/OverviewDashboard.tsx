
import React, { useState } from 'react';
import { DepartmentData, DepartmentId, WeightConfig, AppConfig, WeeklySnapshot } from '../types';
import { IconResolver } from '../utils/iconMap';
import { 
  Calendar, 
  ArrowRight,
  LayoutGrid,
  Layers,
  CheckCircle,
  Clock,
  Zap,
  Check,
  AlertTriangle,
  History,
  TrendingUp,
  TrendingDown,
  Minus,
  PlusCircle,
  X,
  Save,
  Download,
  Activity
} from 'lucide-react';

interface OverviewDashboardProps {
  allData: Record<DepartmentId, DepartmentData>;
  allWeights: Record<DepartmentId, WeightConfig>;
  config: AppConfig;
  snapshots?: WeeklySnapshot[];
  hasSnapshotPermission?: boolean;
  onSaveSnapshot?: (snapshot: WeeklySnapshot) => void;
  onNavigate: (deptId: DepartmentId) => void;
}

const OverviewDashboard: React.FC<OverviewDashboardProps> = ({ 
  allData, 
  allWeights, 
  config, 
  snapshots = [],
  hasSnapshotPermission = false,
  onSaveSnapshot,
  onNavigate 
}) => {
  const [retroModalOpen, setRetroModalOpen] = useState(false);
  const [selectedRetroDate, setSelectedRetroDate] = useState<Date | null>(null);
  const [manualScores, setManualScores] = useState<Record<string, number>>({});

  // --- Cálculos de Tempo ---
  const startDate = new Date('2026-01-20').getTime();
  const endDate = new Date('2026-04-20').getTime();
  const today = new Date();
  const todayTs = today.getTime();
  const totalDays = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
  const daysElapsed = Math.max(0, Math.ceil((todayTs - startDate) / (1000 * 60 * 60 * 24)));
  const timeProgress = Math.min(100, Math.max(0, (daysElapsed / totalDays) * 100));

  // Determine Next Wednesday
  const getNextWednesday = () => {
    const d = new Date();
    d.setDate(d.getDate() + (3 + 7 - d.getDay()) % 7);
    return d;
  };
  const nextWed = getNextWednesday();
  const isWednesday = today.getDay() === 3;
  const formattedDate = today.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });

  // --- Geração de Datas Semanais (Quartas-feiras) ---
  const generateQuarterWednesdays = () => {
    const dates = [];
    // Start from Jan 21, 2026 (Wednesday)
    let current = new Date('2026-01-21T12:00:00');
    const end = new Date('2026-04-20T23:59:59');
    
    while (current <= end) {
      dates.push(new Date(current));
      current.setDate(current.getDate() + 7);
    }
    return dates;
  };

  const quarterDates = generateQuarterWednesdays();

  // --- Processamento de Dados Atuais (Snapshot Calculator) ---
  const deptProgress = (Object.entries(allData) as [DepartmentId, DepartmentData][]).map(([deptId, data]) => {
    const deptConfig = config.departments.find(d => d.id === deptId);
    if (!deptConfig) return null;

    const weights = allWeights[deptId as DepartmentId] || { kpiWeight: 50, goalWeight: 50, kpis: {}, goals: {} };
    
    // Score KPIs
    let totalKpiScore = 0;
    let totalKpiWeightDivisor = 0;
    data.kpis.forEach(kpi => {
      const w = weights.kpis[kpi.id] || (100 / (data.kpis.length || 1));
      totalKpiWeightDivisor += w;
      let score = 0;
      if (kpi.trend === 'up') {
        score = Math.min(100, (kpi.value / kpi.target) * 100);
      } else {
        score = kpi.value <= kpi.target ? 100 : Math.max(0, (kpi.target / kpi.value) * 100);
      }
      totalKpiScore += score * w;
    });
    const kpiFinal = totalKpiWeightDivisor > 0 ? totalKpiScore / totalKpiWeightDivisor : 0;

    // Score Goals
    let totalGoalScore = 0;
    let totalGoalWeightDivisor = 0;
    data.goals.forEach(goal => {
      const w = weights.goals[goal.id] || (100 / (data.goals.length || 1));
      totalGoalWeightDivisor += w;
      totalGoalScore += goal.progress * w;
    });
    const goalFinal = totalGoalWeightDivisor > 0 ? totalGoalScore / totalGoalWeightDivisor : 0;

    // Total Dept Score
    const totalScore = (kpiFinal * weights.kpiWeight / 100) + (goalFinal * weights.goalWeight / 100);

    return {
      id: deptId as DepartmentId,
      name: data.name,
      icon: deptConfig.icon,
      score: totalScore,
      kpiScore: kpiFinal,
      goalScore: goalFinal
    };
  }).filter(Boolean) as any[];

  // --- Mapeamento de Snapshots ---
  const snapshotMap = new Map<string, WeeklySnapshot>();
  snapshots.forEach(s => {
    // Normalizar chave por data (YYYY-MM-DD)
    const key = new Date(s.date).toISOString().split('T')[0];
    snapshotMap.set(key, s);
  });

  // Agregação por Categoria
  const categoryStats: Record<string, { totalProgress: number; count: number; completedCount: number }> = {};
  (Object.values(allData) as DepartmentData[]).forEach(dept => {
     dept.goals.forEach(goal => {
       if (!categoryStats[goal.category]) {
         categoryStats[goal.category] = { totalProgress: 0, count: 0, completedCount: 0 };
       }
       categoryStats[goal.category].totalProgress += goal.progress;
       categoryStats[goal.category].count += 1;
       if (goal.progress === 100) categoryStats[goal.category].completedCount += 1;
     });
  });

  const categoryList = Object.entries(categoryStats).map(([catId, stats]) => ({
    id: catId,
    ...config.categories[catId], 
    avgProgress: stats.totalProgress / stats.count,
    count: stats.count,
    completed: stats.completedCount
  })).sort((a, b) => b.avgProgress - a.avgProgress);

  // Score Global Atual
  const globalScore = deptProgress.length > 0 
    ? deptProgress.reduce((acc, curr) => acc + curr.score, 0) / deptProgress.length
    : 0;

  // --- Handlers de Check-in ---
  
  // Helper para formatar data para o input date (YYYY-MM-DD)
  const formatDateForInput = (date: Date) => {
    return date.toISOString().split('T')[0];
  };
  
  // Abre o modal para um "Novo Registro" usando a data de hoje e valores atuais
  const handleOpenNewCheckIn = () => {
    // Encontrar a data de referência (quarta-feira) mais próxima de hoje
    const now = new Date().getTime();
    const sortedDates = [...quarterDates].sort((a, b) => 
      Math.abs(a.getTime() - now) - Math.abs(b.getTime() - now)
    );
    const closestDate = sortedDates[0];
    
    // Usar a data mais próxima encontrada, ou fallback para hoje se der algo errado
    const targetDate = closestDate || new Date();
    const targetKey = formatDateForInput(targetDate);
    const existing = snapshotMap.get(targetKey);

    const initialScores: Record<string, number> = {};
    
    // Se já existe registro para essa data, carrega ele. 
    // Se não, carrega os valores atuais calculados (performance em tempo real).
    if (existing) {
      Object.assign(initialScores, existing.departmentScores);
    } else {
      deptProgress.forEach(d => initialScores[d.id] = parseFloat(d.score.toFixed(1)));
    }

    setManualScores(initialScores);
    setSelectedRetroDate(targetDate);
    setRetroModalOpen(true);
  };

  // Abre o modal para uma data passada específica (clicando na tabela)
  const openRetroModal = (date: Date) => {
    if (!hasSnapshotPermission) return;
    const key = formatDateForInput(date);
    const existing = snapshotMap.get(key);
    
    const initialScores: Record<string, number> = {};
    
    if (existing) {
      Object.assign(initialScores, existing.departmentScores);
    } else {
      // Se não existe, inicializa com 0 para retroativo (usuário vai inserir manualmente)
      deptProgress.forEach(d => initialScores[d.id] = 0);
    }

    setManualScores(initialScores);
    setSelectedRetroDate(date);
    setRetroModalOpen(true);
  };

  const handleDateChangeInModal = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (!e.target.value) return;
    
    // Criar data baseada no input (YYYY-MM-DD), forçando meio-dia para evitar problemas de fuso
    const newDate = new Date(e.target.value + 'T12:00:00');
    setSelectedRetroDate(newDate);

    // Verificar se existe snapshot para essa nova data
    const key = formatDateForInput(newDate);
    const existing = snapshotMap.get(key);

    if (existing) {
      // Se existir, carrega os dados existentes
      setManualScores(existing.departmentScores);
    }
    // Se não existir, mantemos os valores que já estavam na tela
  };

  const fillWithCurrentData = () => {
    // Pega os dados atuais calculados em deptProgress
    const currentScores: Record<string, number> = {};
    deptProgress.forEach(d => currentScores[d.id] = parseFloat(d.score.toFixed(1)));
    setManualScores(currentScores);
  };

  const saveRetroSnapshot = () => {
    if (!selectedRetroDate || !onSaveSnapshot) return;

    const deptScores = { ...manualScores };
    const overall = Object.values(deptScores).reduce((a: number, b: number) => a + b, 0) / (Object.keys(deptScores).length || 1);
    
    const snapshotId = formatDateForInput(selectedRetroDate);
    const label = selectedRetroDate.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });

    const snapshot: WeeklySnapshot = {
      id: snapshotId,
      date: selectedRetroDate.toISOString(),
      timestamp: selectedRetroDate.getTime(),
      weekLabel: label,
      overallScore: overall,
      departmentScores: deptScores,
      categoryScores: {} 
    };

    onSaveSnapshot(snapshot);
    setRetroModalOpen(false);
  };

  // Gauge Helper
  const radius = 85; 
  const stroke = 10;
  const normalizedScore = Math.min(100, Math.max(0, globalScore));
  const circumference = radius * Math.PI;
  const strokeDashoffset = circumference - (normalizedScore / 100) * circumference;

  return (
    <div className="space-y-8 animate-fade-in pb-10">
      
      {/* 1. TOP STATS CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Card 1: Atingimento Geral - Visual Compacto e Aprimorado */}
        <div className="rounded-[24px] p-[1px] shadow-xl relative overflow-hidden group h-full">
           {/* Animated Border Gradient */}
           <div className="absolute inset-0 bg-gradient-to-br from-violet-500 via-[#002FC9] to-[#009655] opacity-50 blur-[1px]"></div>
           
           <div className="relative bg-[#000C33] h-full w-full rounded-[23px] p-6 overflow-hidden flex flex-col justify-between">
               {/* Background Effects */}
               <div className="absolute top-0 right-0 w-64 h-64 bg-violet-600/20 opacity-40 blur-[80px] rounded-full mix-blend-screen pointer-events-none"></div>
               <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#009655]/10 opacity-30 blur-[80px] rounded-full mix-blend-screen pointer-events-none"></div>

               {/* Header */}
               <div className="relative z-10 flex justify-between items-start mb-2">
                  <div>
                     <h3 className="text-white text-lg font-bold tracking-tight flex items-center gap-2">
                        Atingimento Geral
                     </h3>
                     <p className="text-white/50 text-[10px] font-bold uppercase tracking-widest">Performance Ponderada</p>
                  </div>
                  {/* Status Badge */}
                  <div className="px-2 py-1 rounded-lg bg-white/5 border border-white/10 backdrop-blur-sm flex items-center gap-1.5">
                       <Activity className="w-3.5 h-3.5 text-[#009655]" />
                       <span className="text-[10px] font-bold text-[#009655]">Ativo</span>
                  </div>
               </div>
               
               <div className="flex-1 flex flex-col items-center justify-center relative min-h-[140px]">
                  
                  {/* New Gauge Design - Semi Circle with Glow */}
                  <div className="relative w-full max-w-[280px] aspect-[2/1] overflow-hidden flex items-end justify-center mt-4">
                       <svg className="w-full h-full overflow-visible" viewBox="0 0 200 110">
                         <defs>
                             <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" stopColor="#8b5cf6" />
                                <stop offset="50%" stopColor="#002FC9" />
                                <stop offset="100%" stopColor="#009655" />
                             </linearGradient>
                             <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                               <feGaussianBlur stdDeviation="4" result="blur" />
                               <feComposite in="SourceGraphic" in2="blur" operator="over" />
                             </filter>
                         </defs>
                         
                         {/* Background Track */}
                         <path d="M 15 100 A 85 85 0 0 1 185 100" fill="none" stroke="#1e293b" strokeWidth={stroke} strokeLinecap="round" />
                         
                         {/* Progress Arc */}
                         <path 
                             d="M 15 100 A 85 85 0 0 1 185 100" 
                             fill="none" 
                             stroke="url(#gaugeGradient)" 
                             strokeWidth={stroke} 
                             strokeLinecap="round" 
                             strokeDasharray={circumference} 
                             strokeDashoffset={strokeDashoffset} 
                             className="transition-all duration-1000 ease-out"
                             filter="url(#glow)"
                         />
                       </svg>
                       
                       {/* Central Value Overlay */}
                       <div className="absolute bottom-0 left-1/2 -translate-x-1/2 flex flex-col items-center mb-1">
                          <span className="text-5xl font-black text-white tracking-tighter drop-shadow-[0_0_15px_rgba(0,47,201,0.6)]">
                              {globalScore.toFixed(0)}<span className="text-2xl text-blue-300/50 align-top">%</span>
                          </span>
                       </div>
                  </div>
                  
                  {/* Labels Container - Flex to prevent cut-off */}
                  <div className="w-full max-w-[290px] flex justify-between px-1 mt-[-8px] relative z-10">
                      <span className="text-[10px] font-bold text-slate-500">0%</span>
                      <span className="text-[10px] font-bold text-slate-500">100%</span>
                  </div>
               </div>

               {/* Footer Quote */}
               <div className="relative z-10 text-center mt-3 border-t border-white/5 pt-3">
                  <p className="text-white/40 text-[10px] font-medium italic tracking-wide">"O que não é medido, não é gerenciado."</p>
               </div>
           </div>
        </div>

        {/* Card 2: Prazo & Check-in */}
        <div className="bg-gradient-to-br from-white to-blue-50/40 rounded-[24px] p-6 shadow-sm border border-blue-100/50 flex flex-col justify-between relative overflow-hidden group">
           <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#002FC9]"></div>
           <div className="absolute top-0 right-0 w-32 h-32 bg-blue-100/20 rounded-bl-full -mr-10 -mt-10 group-hover:scale-110 transition-transform duration-500"></div>
           <div className="pl-2">
             <h3 className="text-[#000C33] text-lg font-black tracking-tight flex items-center gap-2">
               <Calendar className="w-5 h-5 text-[#002FC9]" />
               Prazo Q1
             </h3>
             <div className="flex justify-between items-end mt-4 mb-3">
               <div>
                  <span className="text-4xl font-black text-[#000C33] tracking-tighter">{timeProgress.toFixed(0)}%</span>
                  <span className="text-[10px] text-slate-400 font-bold ml-1.5 uppercase">Concluído</span>
               </div>
               <div className="text-right">
                  <span className="block text-xl font-bold text-slate-700">{daysElapsed} <span className="text-[10px] text-slate-400 font-bold">DIAS</span></span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{totalDays - daysElapsed} restantes</span>
               </div>
             </div>
             <div className="relative h-3 bg-slate-200/60 rounded-full mt-2 overflow-hidden">
                <div className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#000C33] to-[#1e40af] rounded-full transition-all duration-1000 shadow-[0_0_10px_rgba(30,64,175,0.3)]" style={{ width: `${timeProgress}%` }}></div>
             </div>
             <div className="flex justify-between text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-widest">
               <span>20 Jan</span>
               <span>20 Abr</span>
             </div>
           </div>
           <div className="mt-6 pt-4 border-t border-blue-100/50 flex items-center justify-between pl-2">
              <div className="flex items-center gap-2">
                 <Clock className={`w-3.5 h-3.5 ${isWednesday ? 'text-[#009655]' : 'text-slate-400'}`} />
                 <span className={`text-[11px] font-bold ${isWednesday ? 'text-[#009655]' : 'text-slate-500'}`}>
                    {isWednesday ? 'Hoje é dia de Check-in!' : `Próximo: ${nextWed.getDate()}/${nextWed.getMonth()+1}`}
                 </span>
              </div>
              {hasSnapshotPermission ? (
                <button 
                  onClick={handleOpenNewCheckIn}
                  className="bg-[#002FC9] hover:bg-[#0025a0] text-white px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wide shadow-lg shadow-blue-600/20 transition-all active:scale-95 flex items-center gap-2 group-hover:shadow-blue-600/30"
                >
                  <Check className="w-3.5 h-3.5" />
                  Check-in
                </button>
              ) : (
                <div className="text-[10px] text-slate-400 italic">Apenas gestores</div>
              )}
           </div>
        </div>

      </div>

      {/* 2. EVOLUÇÃO HISTÓRICA */}
      <div className="bg-white rounded-[24px] p-8 shadow-sm border border-slate-100 overflow-hidden">
         {/* ... Rest of the component remains the same ... */}
         <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-black text-[#000C33] flex items-center gap-2">
              <History className="w-5 h-5 text-blue-600" />
              Evolução Histórica por Área
            </h3>
            <div className="text-xs text-slate-400 font-bold uppercase tracking-wide">
              Check-ins Semanais (Quartas-feiras)
            </div>
         </div>
         
         <div className="overflow-x-auto pb-4">
           <table className="w-full min-w-[800px] border-collapse">
             <thead>
               <tr>
                 {/* COLUNA 1: Área (Sticky) */}
                 <th className="text-left py-4 px-4 text-[11px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 w-[250px] min-w-[250px] sticky left-0 bg-white z-20 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]">
                   Área / Departamento
                 </th>

                 {/* COLUNA 2: Hoje (Sticky) */}
                 <th className="text-center py-4 px-4 text-[11px] font-black text-[#002FC9] uppercase tracking-widest border-b border-slate-100 w-[120px] min-w-[120px] sticky left-[250px] bg-white z-20 shadow-[4px_0_10px_-4px_rgba(0,0,0,0.1)] border-r border-slate-100">
                    Hoje
                 </th>

                 {/* COLUNAS DE DATA (Scrollable) */}
                 {quarterDates.map((date, i) => {
                   const isFuture = date > new Date();
                   const dateKey = date.toISOString().split('T')[0];
                   const hasSnapshot = snapshotMap.has(dateKey);
                   
                   return (
                     <th key={dateKey} className={`text-center py-4 px-4 text-[11px] font-black uppercase tracking-widest border-b border-slate-100 min-w-[100px] ${isFuture ? 'text-slate-300' : 'text-slate-500'}`}>
                       <div className={`flex flex-col items-center group ${!isFuture && hasSnapshotPermission ? 'cursor-pointer' : ''}`} onClick={() => !isFuture && hasSnapshotPermission && openRetroModal(date)}>
                         <span className={`${hasSnapshot ? 'text-[#002FC9]' : ''}`}>{date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}</span>
                         {hasSnapshot && (
                           <span className="text-[9px] text-[#009655] font-bold bg-emerald-50 px-1.5 rounded mt-0.5">OK</span>
                         )}
                         {!hasSnapshot && !isFuture && hasSnapshotPermission && (
                           <span className="text-[9px] text-slate-300 font-bold bg-slate-50 px-1.5 rounded mt-0.5 group-hover:text-blue-500 group-hover:bg-blue-50 transition-colors">+ Add</span>
                         )}
                       </div>
                     </th>
                   );
                 })}
               </tr>
             </thead>
             <tbody>
               {deptProgress.map((dept) => {
                 // --- Cálculo da Diferença Hoje vs Último Snapshot ---
                 let lastSnapshotScore = 0;
                 let hasLastSnapshot = false;
                 
                 for (let i = quarterDates.length - 1; i >= 0; i--) {
                    const dateKey = quarterDates[i].toISOString().split('T')[0];
                    const snap = snapshotMap.get(dateKey);
                    
                    if (snap && snap.departmentScores[dept.id] !== undefined) {
                        lastSnapshotScore = snap.departmentScores[dept.id];
                        hasLastSnapshot = true;
                        break; 
                    }
                 }

                 const todayDelta = hasLastSnapshot ? dept.score - lastSnapshotScore : 0;
                 const isPositive = todayDelta > 0;
                 const isZero = Math.abs(todayDelta) < 0.1;

                 return (
                   <tr key={dept.id} className="group hover:bg-slate-50 transition-colors">
                     {/* CELULA 1: NOME DA ÁREA */}
                     <td className="py-4 px-4 border-b border-slate-50 group-last:border-0 sticky left-0 bg-white group-hover:bg-slate-50 z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]">
                       <div className="flex items-center gap-3">
                         <div className="p-2 bg-slate-100 rounded-lg text-slate-500">
                           <IconResolver iconName={dept.icon} className="w-4 h-4" />
                         </div>
                         <span className="font-bold text-sm text-[#000C33]">{dept.name}</span>
                       </div>
                     </td>

                     {/* CELULA 2: VALOR HOJE (Congelado) */}
                     <td className="py-4 px-4 border-b border-slate-50 group-last:border-0 text-center sticky left-[250px] bg-white group-hover:bg-slate-50 z-10 shadow-[4px_0_10px_-4px_rgba(0,0,0,0.1)] border-r border-slate-50">
                        <div className="flex flex-col items-center gap-1">
                            <span className={`text-lg font-black ${dept.score >= 100 ? 'text-emerald-600' : 'text-[#002FC9]'}`}>
                              {dept.score.toFixed(0)}%
                            </span>
                            
                            {hasLastSnapshot && !isZero && (
                                <div className={`text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center ${isPositive ? 'text-emerald-600 bg-emerald-100/50' : 'text-rose-600 bg-rose-100/50'}`}>
                                    {isPositive ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                                    {isPositive ? '+' : ''}{todayDelta.toFixed(0)}%
                                </div>
                            )}
                        </div>
                     </td>
                     
                     {/* CELULAS: DATAS */}
                     {quarterDates.map((date, i) => {
                       const dateKey = date.toISOString().split('T')[0];
                       const snapshot = snapshotMap.get(dateKey);
                       const score = snapshot ? snapshot.departmentScores[dept.id] || 0 : null;
                       
                       let delta = 0;
                       let hasPrev = false;
                       if (i > 0 && score !== null) {
                          const prevDateKey = quarterDates[i-1].toISOString().split('T')[0];
                          const prevSnap = snapshotMap.get(prevDateKey);
                          if (prevSnap && prevSnap.departmentScores[dept.id] !== undefined) {
                             delta = score - prevSnap.departmentScores[dept.id];
                             hasPrev = true;
                          }
                       }

                       const isFuture = date > new Date();

                       return (
                         <td key={`${dept.id}-${dateKey}`} className="py-4 px-4 border-b border-slate-50 group-last:border-0 text-center relative">
                            {score !== null ? (
                              <div className="flex flex-col items-center gap-1">
                                 <span className={`text-sm font-black ${score >= 100 ? 'text-emerald-600' : score < 50 ? 'text-amber-600' : 'text-slate-700'}`}>
                                   {score.toFixed(0)}%
                                 </span>
                                 {hasPrev && Math.abs(delta) > 0.1 && (
                                   <div className={`text-[9px] font-bold flex items-center ${delta > 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                                      {delta > 0 ? <TrendingUp className="w-2.5 h-2.5 mr-0.5" /> : <TrendingDown className="w-2.5 h-2.5 mr-0.5" />}
                                      {Math.abs(delta).toFixed(0)}%
                                   </div>
                                 )}
                              </div>
                            ) : (
                              <span className="text-slate-200 text-xs font-bold">{isFuture ? '' : '-'}</span>
                            )}
                         </td>
                       );
                     })}
                   </tr>
                 );
               })}
             </tbody>
           </table>
         </div>
      </div>

      {/* 3. GRID INFERIOR */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-[24px] p-6 shadow-sm border border-slate-100">
           <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-black text-[#000C33] flex items-center gap-2">
                <Layers className="w-5 h-5 text-purple-600" />
                Pilares Estratégicos
              </h3>
           </div>
           <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
             {categoryList.map((item) => {
               const catConfig = config.categories[item.id];
               if (!catConfig) return null;
               return (
                 <div key={item.id} className="flex items-center gap-4 p-3 rounded-xl bg-slate-50 border border-slate-100 hover:border-blue-200 transition-colors">
                    <div className={`p-2 rounded-lg bg-${catConfig.colorTheme}-100 text-${catConfig.colorTheme}-600`}>
                      <IconResolver iconName={catConfig.icon} className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <span className="text-xs font-bold text-[#000C33]">{catConfig.label}</span>
                        <span className="text-xs font-black text-slate-500">{item.avgProgress.toFixed(0)}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-1.5">
                        <div className={`h-1.5 rounded-full bg-${catConfig.colorTheme}-500`} style={{ width: `${item.avgProgress}%` }}></div>
                      </div>
                    </div>
                 </div>
               )
             })}
           </div>
        </div>

        <div className="bg-white rounded-[24px] p-6 shadow-sm border border-slate-100">
          <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-black text-[#000C33] flex items-center gap-2">
                <LayoutGrid className="w-5 h-5 text-indigo-600" />
                Performance por Área
              </h3>
           </div>
           <div className="grid grid-cols-2 gap-3">
             {deptProgress.map((dept) => (
               <div 
                 key={dept.id}
                 onClick={() => onNavigate(dept.id)}
                 className="p-3 rounded-xl border border-slate-100 hover:border-blue-500 hover:shadow-md transition-all cursor-pointer group bg-white"
               >
                 <div className="flex items-center gap-2 mb-2">
                   <IconResolver iconName={dept.icon} className="w-4 h-4 text-slate-400 group-hover:text-blue-600" />
                   <span className="text-xs font-bold text-[#000C33] truncate">{dept.name}</span>
                 </div>
                 <div className="flex items-end justify-between">
                   <span className={`text-lg font-black ${dept.score >= 100 ? 'text-emerald-500' : dept.score > 50 ? 'text-[#002FC9]' : 'text-amber-500'}`}>
                     {dept.score.toFixed(0)}%
                   </span>
                   <ArrowRight className="w-3 h-3 text-slate-300 group-hover:text-blue-500 transform group-hover:translate-x-1 transition-all" />
                 </div>
               </div>
             ))}
           </div>
        </div>
      </div>

      {/* MODAL DE CHECK-IN RETROATIVO / ATUAL */}
      {retroModalOpen && selectedRetroDate && (
        <div className="fixed inset-0 bg-[#000C33]/80 z-50 flex items-center justify-center backdrop-blur-md p-4 animate-in fade-in">
          <div className="bg-white rounded-[32px] w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="bg-[#000C33] px-8 py-6 flex justify-between items-center shrink-0">
              <div className="flex items-center gap-3">
                <div className="bg-blue-600/20 p-2 rounded-xl text-blue-400">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">Registrar Check-in</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-blue-200/60 text-xs">Data de referência:</span>
                    <select 
                      value={formatDateForInput(selectedRetroDate)}
                      onChange={handleDateChangeInModal}
                      className="bg-white/10 border border-white/10 rounded px-2 py-0.5 text-xs text-white font-bold focus:outline-none focus:border-blue-500 [&>option]:text-slate-900"
                    >
                       {quarterDates.map((date) => (
                          <option key={date.toISOString()} value={formatDateForInput(date)}>
                             {date.toLocaleDateString('pt-BR')} {snapshotMap.has(formatDateForInput(date)) ? '(Salvo)' : ''}
                          </option>
                       ))}
                    </select>
                  </div>
                </div>
              </div>
              <button onClick={() => setRetroModalOpen(false)} className="text-white/50 hover:text-white transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-8 overflow-y-auto bg-[#F8FAFC] space-y-4">
              <div className="flex justify-between items-center bg-blue-50 p-3 rounded-xl border border-blue-100 mb-2">
                 <p className="text-sm text-slate-500">
                   Insira a porcentagem de atingimento.
                 </p>
                 <button 
                   onClick={fillWithCurrentData}
                   className="flex items-center gap-2 px-3 py-1.5 bg-blue-100 text-blue-700 rounded-lg text-xs font-bold hover:bg-blue-200 transition-colors"
                 >
                   <Download className="w-3 h-3" />
                   Usar Valores Atuais
                 </button>
              </div>
              
              {deptProgress.map(dept => (
                <div key={dept.id} className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 flex items-center justify-center bg-slate-100 rounded-lg text-slate-500">
                      <IconResolver iconName={dept.icon} className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-sm text-[#000C33]">{dept.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      min="0" 
                      max="999"
                      value={manualScores[dept.id] ?? 0}
                      onChange={(e) => setManualScores({...manualScores, [dept.id]: parseFloat(e.target.value) || 0})}
                      className="w-20 text-right font-bold text-lg text-[#002FC9] bg-transparent border-b-2 border-slate-200 focus:border-[#002FC9] outline-none"
                    />
                    <span className="text-sm font-bold text-slate-400">%</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 bg-white border-t border-slate-200 flex justify-end gap-3 shrink-0">
              <button onClick={() => setRetroModalOpen(false)} className="px-6 py-3 text-slate-600 font-bold hover:bg-slate-50 rounded-xl transition-colors text-sm">
                Cancelar
              </button>
              <button onClick={saveRetroSnapshot} className="px-6 py-3 bg-[#002FC9] text-white font-bold rounded-xl hover:bg-[#0025a0] shadow-lg shadow-blue-500/20 flex items-center gap-2">
                <Save className="w-4 h-4" />
                Salvar Registro
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default OverviewDashboard;
