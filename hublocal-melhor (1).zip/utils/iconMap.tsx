
import React from 'react';
import { 
  Users, DollarSign, TrendingUp, Shield, Activity, 
  Server, Zap, PieChart, Briefcase, Phone, Heart, UserPlus,
  Rocket, HeartHandshake, BarChart2, Coins, Brain, Layout,
  Database, Cpu, Trophy, Target, Globe, Layers, Box, 
  Lightbulb, Flag, Key, Lock, Anchor, Truck, ShoppingCart,
  Megaphone, Smartphone, Monitor, Code, Settings, PenTool,
  Hash, Percent, Star, CheckCircle, AlertTriangle, Clock
} from 'lucide-react';

// Organized for the UI Picker
export const ICON_CATEGORIES = {
  'Estratégia & Crescimento': {
    Rocket, TrendingUp, Target, Trophy, Flag, Globe, Lightbulb, Brain
  },
  'Negócios & Vendas': {
    DollarSign, Coins, Briefcase, Phone, ShoppingCart, Truck, Megaphone, HeartHandshake
  },
  'Operações & Pessoas': {
    Users, UserPlus, Heart, Shield, Activity, Layers, Box, Anchor
  },
  'Tecnologia & Dados': {
    Server, Database, Cpu, Code, Monitor, Smartphone, Zap, BarChart2, PieChart
  },
  'Geral & UI': {
    Settings, Layout, PenTool, Key, Lock, Hash, Percent, Star, CheckCircle, AlertTriangle, Clock
  }
};

// Flattened for resolution
export const ALL_ICONS: Record<string, any> = Object.values(ICON_CATEGORIES).reduce((acc, group) => ({ ...acc, ...group }), {});

export const IconResolver = ({ iconName, className }: { iconName: string, className?: string }) => {
  const Icon = ALL_ICONS[iconName] || Target;
  return <Icon className={className} />;
};
